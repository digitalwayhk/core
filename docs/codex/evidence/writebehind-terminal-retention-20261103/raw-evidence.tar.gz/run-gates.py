import subprocess,os,time,json
from pathlib import Path
root=Path(__file__).resolve().parent
checks=[("examples",["go","test","./examples/04-shop-performance/...","./examples/07-shop-order-scale/...","-count=1","-timeout=300s"]),("examples-race",["go","test","-race","./examples/04-shop-performance/...","./examples/07-shop-order-scale/...","-count=1","-timeout=300s"]),("persistence-unit",["./scripts/test.sh","persistence-unit"]),("config-contract",["./scripts/test.sh","config-contract"]),("performance-contract",["./scripts/test.sh","performance-contract"]),("release-contract",["./scripts/test.sh","release-contract"]),("ai-skill",["./scripts/check-ai-skill.sh"]),("web-dist",["./scripts/check-web-dist-sync.sh"]),("logging",["./scripts/check-logging.sh"]),("vet",["go","vet","./pkg/persistence/database/nosql","./examples/04-shop-performance/...","./examples/07-shop-order-scale/..."])]
env=os.environ.copy()
for name in ["CORE_TEST_MYSQL","CORE_TEST_POSTGRES","CORE_REFERENCE_TEST_MYSQL","CORE_TEST_REDIS_ADDR"]:env.pop(name,None)
env["CORE_TERMINAL_OLD_BINARY"]=str(root/"core-v181-nosql.test")
receipts=[]
for name,cmd in checks:
 started=time.time()
 with (root/(name+".log")).open("w") as log:
  child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);code=child.wait()
 row={"name":name,"command":cmd,"pid":child.pid,"exit_code":code,"wall_seconds":time.time()-started};receipts.append(row);(root/"gate-receipts.json").write_text(json.dumps(receipts,indent=2)+"\n");print(json.dumps(row),flush=True)
