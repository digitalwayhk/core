import subprocess,os,json,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
runs=[("final-before-short","core-v181-perf-v2.test",3,3,None),("final-after-short","core-candidate-perf-v2.test",3,3,None),("final-before-steady","core-v181-perf-v2.test",130,1,"bounded_fast_sync"),("final-after-steady","core-candidate-perf-v2.test",130,1,"bounded_fast_sync")]
receipts=[]
for name,binary,seconds,rounds,mode in runs:
 env=os.environ.copy();env.update(CORE_RETENTION_PERF="1",GOMAXPROCS="1",CORE_RETENTION_PERF_SECONDS=str(seconds),CORE_RETENTION_PERF_ROUNDS=str(rounds));env.pop("CORE_RETENTION_PERF_MODE",None)
 if mode:env["CORE_RETENTION_PERF_MODE"]=mode
 env.pop("CORE_RETENTION_PERF_RATE",None)
 if "steady" in name:env["CORE_RETENTION_PERF_RATE"]="500"
 cmd=[str(root/binary),"-test.run=^TestTerminalRetentionPerformance$","-test.v","-test.count=1","-test.timeout=300s"]
 started=time.time()
 with (root/(name+".log")).open("w") as log:
  process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);code=process.wait()
 receipt={"name":name,"command":cmd,"env":{k:v for k,v in env.items() if k.startswith("CORE_RETENTION_PERF") or k=="GOMAXPROCS"},"pid":process.pid,"exit_code":code,"wall_seconds":time.time()-started,"binary_sha256":hashlib.sha256((root/binary).read_bytes()).hexdigest()};receipts.append(receipt)
 (root/"performance-final-receipts.json").write_text(json.dumps(receipts,indent=2)+"\n")
 print(json.dumps(receipt),flush=True)
