# 主 Agent 五维自审（不是独立审计）

- 正确性：已从旧正式对象绑定 Outbox RED；首个前序失败保留、同key后继不越过；资格恢复重新读earliest-first，不直接继续旧切片。mark失败仍按原批前缀重放，取消不假确认。clear保留同一map引用，不替换drain别名。初版一批容量让BatchSize=1饿死健康项，已先RED再改两批预算。
- 可读性：唯一新辅助函数管理既有worker内存窗口，窗口由Interval派生；deadline和Notify一次提前恢复分开，不新增业务重试分类或配置面。非正Interval只沿原100ms默认。测试局部计数与真实Broker/进程层明确区分。
- 架构：只有outbox.go/outbox_retry.go两个生产文件；不改Provider、EventBridge交付顺序、SQL target、MQ生命周期、组/消息/格式。原runKeyedLanes同批等待保留；任意慢回调仍可能延迟到期检查，不能强杀应用。
- 安全/可靠性：无提前ACK、无消息删除或组游标重置；真实Redis故障只RENAME从未存消息的合成错误类型key并保留其值。未新记录凭据/正文/动态指标。私有Bitzoom测试复制被自动审批拒绝，已改用Core独立夹具，不绕行取数。
- 性能/资源：只增加每publisher一个复用timer及有界failed-key map；最多3*batch-1个key（依赖Store遵守limit），原worker并发和batch保持。Notify每窗口至多一次提前资格，不因通知风暴无限清屏障。达到两批预算形成背压；NoSkip满失败前缀与无限故障key全局公平不做承诺。窗口不是新的业务SLO，既有SQL/handler成本不归因于此。

最终结论以完整普通/race/真实Redis/进程和发布门禁结果为准；未跑消费方部署/UAT/容量，不将组件测试当现场完成。无待处理Critical代码问题；依赖告警、NATS未运行及原查询窗口局限明确列边界，不在本专项扩改。
