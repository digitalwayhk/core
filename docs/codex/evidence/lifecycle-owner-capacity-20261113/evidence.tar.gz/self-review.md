# 主Agent五维自审（不是独立外部审计）

1. 正确性：当前正式v1.11.2原对象绑定；原controller/真实Redis/race功能RED保留，候选不放弱原前序/容量断言。仅协调owner+可恢复deadline+父轮次有余量触发一次补读；metadata/policy/owner/取消语义优先。ctx与entry/policy在存储前再次核验。补读失败标记不可用，不以旧完整容量伪装补读成功；完整快照/组前沿不动，原完整错误与计数保持，不Reclaim。
2. 简明性：六个生产文件；复用原私有worker能力，未改Provider实现/公开接口/配置/格式/组/游标，无新worker/队列/采样线程。legacy不增加读取。正常owner完整成功、无硬限不加读。新helper只拆分资格/证据校验和诊断。
3. 并发/架构：原CAS每Subject单轮次保持；网络不在controller锁内，外部Error分类先RED再移到锁外。取消不等于实际回调退出，关闭等原回调，迟到nil不能刷容量。日志在锁外、字段仅固定枚举/登记Subject/已知年龄。最终普通/race对锁边界修正后再跑，前轮长租约结果单列。
4. 安全：无提前ACK、丢消息、清PEL/游标、提容量、改observe或重置背压。不把完整错误覆盖成deadline后降级；未知不补0。容量partial不用于安全回收。只用Core自有合成夹具/独占Redis，不读写Bitzoom/Full-E4。
5. 性能/资源：每失败owner最多一次原4命令管线，约150ms剩余ctx继承而非新500ms。8Subject实测命令增量有界，13×44正常轮次命令去重另回归。诊断原entry固定字段/6原因+3补读计数，无消息维度map/动态指标标签。日志同状态一次，变化也按原Interval限频。没有生产同档机器/稳态/业务P99结论。

保留的候选FAIL：取消+deadline原优先级触发不应有的补读；外部error.Error在全局锁内。两项均先RED再最小修复，原断言不变。NATS真实Broker、消费方接入/部署/UAT/容量及每次现场unknown归因明确NOT_RUN；不把组件结果当全部异步问题解决。剩余预算也失败时仍unknown，完整扫描持续失败仍不回收，可最终达到真实硬限，这是保留的安全背压。
