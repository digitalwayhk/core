// 本文件验证生命周期轮次所有权前置和独立阶段预算，不替代真实 Broker 契约。
package mq

import (
	"context"
	"errors"
	"fmt"
 "os"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

type workerTestProvider struct {
	lifecycleTestProvider
	owner   bool
	delay   time.Duration
	expired atomic.Bool
}

type scheduledLifecycleProvider struct {
	workerTestProvider
	mu      sync.Mutex
	seen    map[string]bool
	started chan<- time.Time
}

func (p *scheduledLifecycleProvider) InspectLifecycle(ctx context.Context, policy LifecyclePolicy) (LifecycleSnapshot, error) {
	p.mu.Lock()
	first := !p.seen[policy.Subject]
	p.seen[policy.Subject] = true
	p.mu.Unlock()
	if first {
		p.started <- time.Now()
	}
	return p.workerTestProvider.InspectLifecycle(ctx, policy)
}

// TestLifecycleRegisteredWorkersSpreadStartup 通过真实 worker 定时器验证 13×44 次首次扫描不在同一时间点触发。
func TestLifecycleRegisteredWorkersSpreadStartup(t *testing.T) {
	started := make(chan time.Time, 13*44)
	for instance := 0; instance < 13; instance++ {
		c := newLifecycleController()
		defer c.stop()
		p := &scheduledLifecycleProvider{workerTestProvider: workerTestProvider{owner: true}, seen: make(map[string]bool), started: started}
		for subject := 0; subject < 44; subject++ {
			policy := validLifecyclePolicy("required")
			policy.Subject = fmt.Sprintf("fills-%d", subject)
			policy.Reclaim.Interval = 200 * time.Millisecond
			policy.Reclaim.TimeBudget = 100 * time.Millisecond
			c.mu.Lock()
			c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p}
			c.mu.Unlock()
			c.wg.Add(1)
			go c.runWorker(policy.Subject, policy.Reclaim.Interval)
		}
	}
	timer := time.NewTimer(2 * time.Second)
	defer timer.Stop()
	var first, last time.Time
	for i := 0; i < 13*44; i++ {
		select {
		case stamp := <-started:
			if first.IsZero() || stamp.Before(first) {
				first = stamp
			}
			if stamp.After(last) {
				last = stamp
			}
		case <-timer.C:
			t.Fatal("workers did not start within bounded jitter window")
		}
	}
	require.Greater(t, last.Sub(first), 100*time.Millisecond, "first scans must not share one phase")
}

// TestLifecycleWorkerFailureReasons 验证固定原因计数不会丢失 deadline，且保留总计数。
func TestLifecycleWorkerFailureReasons(t *testing.T) {
	p := &workerTestProvider{owner: true, delay: 90 * time.Millisecond}
	c := newLifecycleController()
	defer c.stop()
	policy := validLifecyclePolicy("required")
	policy.Reclaim.TimeBudget = 100 * time.Millisecond
	c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p}
	require.True(t, errors.Is(c.runOnce(context.Background(), policy.Subject), context.DeadlineExceeded))
	snapshot, _ := c.runtimeMetricSnapshot(context.Background())
	require.Equal(t, float64(1), snapshot.Counters["reclaim_fail_total"])
	require.Equal(t, float64(1), snapshot.Counters["reclaim_fail_deadline_total"])
}

// TestLifecycleNonOwnerMetricsDoNotRefreshOldPending 验证容量采集不伪装完整快照新鲜。
func TestLifecycleNonOwnerMetricsDoNotRefreshOldPending(t *testing.T) {
	p := &workerTestProvider{}
	c := newLifecycleController()
	defer c.stop()
	policy := validLifecyclePolicy("required")
	pending := int64(7)
	c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p, snapshot: LifecycleSnapshot{State: LifecycleStateOK, ObservedAt: time.Now().Add(-3 * policy.Reclaim.Interval), PendingMessages: &pending}}
	require.NoError(t, c.runOnce(context.Background(), policy.Subject))
	snapshot, _ := c.runtimeMetricSnapshot(context.Background())
	require.NotContains(t, snapshot.Gauges, "pending_messages")
	require.Equal(t, float64(1), snapshot.Gauges["retained_messages"])
}

func (p *workerTestProvider) acquireLifecycleRound(ctx context.Context, _ LifecyclePolicy, _ string) (context.Context, bool, error) {
	return ctx, p.owner, nil
}
func (p *workerTestProvider) inspectLifecycleCapacity(context.Context, LifecyclePolicy) (LifecycleSnapshot, error) {
	count := int64(1)
	return LifecycleSnapshot{ObservedAt: time.Now(), State: LifecycleStatePartial, RetainedMessages: &count}, nil
}
func (p *workerTestProvider) InspectLifecycle(ctx context.Context, policy LifecyclePolicy) (LifecycleSnapshot, error) {
	if p.delay > 0 {
		select {
		case <-ctx.Done():
			return LifecycleSnapshot{}, ctx.Err()
		case <-time.After(p.delay):
		}
	}
	return p.lifecycleTestProvider.InspectLifecycle(ctx, policy)
}
func (p *workerTestProvider) ReclaimLifecycle(ctx context.Context, policy LifecyclePolicy, snapshot LifecycleSnapshot) (ReclaimResult, error) {
	p.expired.Store(ctx.Err() != nil)
	return p.lifecycleTestProvider.ReclaimLifecycle(ctx, policy, snapshot)
}

// TestLifecycleNonOwnerSkipsInspect 验证非 owner 只刷新容量，不执行组扫描。
func TestLifecycleNonOwnerSkipsInspect(t *testing.T) {
	p := &workerTestProvider{}
	c := newLifecycleController()
	defer c.stop()
	policy := validLifecyclePolicy("required")
	policy.Capacity.HardMessages = 10
	c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p}
	require.NoError(t, c.runOnce(context.Background(), policy.Subject))
	require.Zero(t, p.inspectCalls, "non-owner must not inspect groups")
	require.Zero(t, p.reclaimCalls)
	require.NoError(t, c.allowPublish(policy.Subject))
}

// TestLifecycleSlowInspectPreservesRoundBound 验证慢检查被提前终止，不吞掉回收预留时间。
func TestLifecycleSlowInspectPreservesRoundBound(t *testing.T) {
	p := &workerTestProvider{owner: true, delay: 90 * time.Millisecond}
	c := newLifecycleController()
	defer c.stop()
	policy := validLifecyclePolicy("required")
	policy.Reclaim.TimeBudget = 100 * time.Millisecond
	c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p}
	start := time.Now()
	err := c.runOnce(context.Background(), policy.Subject)
	require.ErrorIs(t, err, context.DeadlineExceeded)
	require.Zero(t, p.reclaimCalls)
	require.Less(t, time.Since(start), 120*time.Millisecond)
}

// TestLifecycleReclaimHasIndependentContext 验证检查阶段取消不传播至回收阶段。
func TestLifecycleReclaimHasIndependentContext(t *testing.T) {
	p := &workerTestProvider{owner: true, delay: 10 * time.Millisecond}
	c := newLifecycleController()
	defer c.stop()
	policy := validLifecyclePolicy("required")
	policy.Reclaim.TimeBudget = 100 * time.Millisecond
	c.entries[policy.Subject] = &lifecycleEntry{policy: policy, provider: p}
	require.NoError(t, c.runOnce(context.Background(), policy.Subject))
	require.Equal(t, 1, p.reclaimCalls)
	require.False(t, p.expired.Load())
}

// TestLifecycleWorkerJitterSpread 验证启动和周期都不是固定同相位，且延迟有界。
func TestLifecycleWorkerJitterSpread(t *testing.T) {
	for _, startup := range []bool{true, false} {
		buckets := make(map[int64]int)
		for i := 0; i < 13*44; i++ {
			delay := lifecycleWorkerDelay(2*time.Second, startup)
			require.Greater(t, delay, time.Duration(0))
			require.Less(t, delay, 2500*time.Millisecond)
			buckets[delay.Milliseconds()/100]++
		}
		require.GreaterOrEqual(t, len(buckets), 8, "jitter must spread registration bursts")
	}
}

// capacityRefreshDiagnosticProvider仅扩展Core原有worker夹具，两个角色使用同一个合法容量源。
type capacityRefreshDiagnosticProvider struct {
 workerTestProvider
 capacityCalls atomic.Int64
}
func (p *capacityRefreshDiagnosticProvider) inspectLifecycleCapacity(ctx context.Context, policy LifecyclePolicy) (LifecycleSnapshot,error) {
 p.capacityCalls.Add(1)
 if err:=ctx.Err();err!=nil {return LifecycleSnapshot{},err}
 count,bytes:=int64(0),int64(4096)
 return LifecycleSnapshot{Subject:policy.Subject,PolicyFingerprint:policy.Fingerprint(),ObservedAt:time.Now(),State:LifecycleStatePartial,RetainedMessages:&count,RetainedBytes:&bytes},nil
}

// TestCapacityRefreshDiagnosticController用正式controller和现有worker夹具验证owner完整检查超时，非owner轻量容量仍可用；旧代码应真实RED。
func TestCapacityRefreshDiagnosticController(t *testing.T) {
 for _,owned:=range []bool{false,true} {
  t.Run(fmt.Sprintf("owner=%t",owned),func(t *testing.T){
   policy:=validLifecyclePolicy("required");policy.Subject="core-capacity-diagnostic";policy.Reclaim.Interval=2*time.Second;policy.Reclaim.TimeBudget=500*time.Millisecond;policy.Capacity.HardBytes=256<<20
   p:=&capacityRefreshDiagnosticProvider{workerTestProvider:workerTestProvider{owner:owned,delay:400*time.Millisecond}}
   c:=newLifecycleController();defer c.stop()
   count,bytes:=int64(0),int64(4096)
   c.entries[policy.Subject]=&lifecycleEntry{policy:policy,provider:p,snapshot:LifecycleSnapshot{Subject:policy.Subject,PolicyFingerprint:policy.Fingerprint(),ObservedAt:time.Now().Add(-5*time.Second),State:LifecycleStateOK,RetainedMessages:&count,RetainedBytes:&bytes}}
   started:=time.Now();roundErr:=c.runOnce(context.Background(),policy.Subject);publishErr:=c.allowPublish(policy.Subject)
   if owned {require.ErrorIs(t,roundErr,context.DeadlineExceeded);require.EqualValues(t,1,c.reclaimReasons[0].Load())} else {require.NoError(t,roundErr)}
   require.Zero(t,p.reclaimCalls)
   c.mu.RLock();fullAt:=c.entries[policy.Subject].snapshot.ObservedAt;capacityPresent:=c.entries[policy.Subject].capacity!=nil;c.mu.RUnlock()
   t.Logf("owner=%t budget=500ms inspect=350ms elapsed=%s round=%v capacity_calls=%d capacity_present=%t full_age=%s publish=%v",owned,time.Since(started),roundErr,p.capacityCalls.Load(),capacityPresent,time.Since(fullAt),publishErr)
   require.NoError(t,publishErr,"CAPACITY_REFRESH_OWNER_GAP: 同样新鲜且低于硬限的容量可用，不应仅因owner全组检查超时丧失容量刷新")
  })
 }
}

type capacityRefreshDiagnosticRedis struct {
 *RedisStreamProvider
 fullCalls atomic.Int64
 capacityCalls atomic.Int64
 reclaimCalls atomic.Int64
}
func (p *capacityRefreshDiagnosticRedis) InspectLifecycle(ctx context.Context,_ LifecyclePolicy)(LifecycleSnapshot,error){p.fullCalls.Add(1);<-ctx.Done();return LifecycleSnapshot{},ctx.Err()}
func (p *capacityRefreshDiagnosticRedis) inspectLifecycleCapacity(ctx context.Context,policy LifecyclePolicy)(LifecycleSnapshot,error){p.capacityCalls.Add(1);return p.RedisStreamProvider.inspectLifecycleCapacity(ctx,policy)}
func (p *capacityRefreshDiagnosticRedis) ReclaimLifecycle(ctx context.Context,policy LifecyclePolicy,snapshot LifecycleSnapshot)(ReclaimResult,error){p.reclaimCalls.Add(1);return p.RedisStreamProvider.ReclaimLifecycle(ctx,policy,snapshot)}

// TestCapacityRefreshDiagnosticRedisOwnerStandby真实Redis lease/轻量管线/实际Publish，完整Inspect仅注入可控deadline，不宣称Redis自然延迟复现。
func TestCapacityRefreshDiagnosticRedisOwnerStandby(t *testing.T){
 addr:=os.Getenv("CORE_TEST_REDIS_ADDR");if addr=="" {t.Skip("NOT_RUN: 需要本轮独占Redis")}
 ctx:=context.Background();prefix:=fmt.Sprintf("core:capacity-diagnostic:%d",time.Now().UnixNano())
 r:=NewRedisStreamProvider(addr,prefix,0);require.NoError(t,r.Connect(ctx));defer r.Close()
 policy:=validLifecyclePolicy("required");policy.Subject="core-capacity-diagnostic";policy.Reclaim.Interval=2*time.Second;policy.Reclaim.TimeBudget=500*time.Millisecond;policy.Capacity.SoftBytes=192<<20;policy.Capacity.HardBytes=256<<20
 require.NoError(t,r.EnsureLifecycle(ctx,policy));before,err:=r.InspectLifecycle(ctx,policy);require.NoError(t,err);require.NotNil(t,before.RetainedBytes);require.Less(t,*before.RetainedBytes,policy.Capacity.HardBytes)
 before.ObservedAt=time.Now().Add(-5*time.Second)
 p:=&capacityRefreshDiagnosticRedis{RedisStreamProvider:r}
 owner:=newLifecycleController();defer owner.stop();owner.entries[policy.Subject]=&lifecycleEntry{policy:policy,provider:p,snapshot:before}
 standby:=newLifecycleController();defer standby.stop();standby.entries[policy.Subject]=&lifecycleEntry{policy:policy,provider:p,snapshot:before}
 start:=time.Now();ownerRound:=owner.runOnce(ctx,policy.Subject);ownerElapsed:=time.Since(start);require.ErrorIs(t,ownerRound,context.DeadlineExceeded)
 ownerCapacityCalls:=p.capacityCalls.Load()
 ownerManager:=&MQManager{current:r,lifecycle:owner};ownerPublish:=ownerManager.Publish(ctx,policy.Subject,[]byte("Core合成容量诊断"),nil)
 available,e:=r.inspectLifecycleCapacity(ctx,policy);require.NoError(t,e);require.NotNil(t,available.RetainedBytes);require.Less(t,*available.RetainedBytes,policy.Capacity.HardBytes)
 start=time.Now();standbyRound:=standby.runOnce(ctx,policy.Subject);standbyElapsed:=time.Since(start);require.NoError(t,standbyRound)
 standbyManager:=&MQManager{current:r,lifecycle:standby};require.NoError(t,standbyManager.Publish(ctx,policy.Subject,[]byte("Core合成容量诊断"),nil))
 require.EqualValues(t,0,p.reclaimCalls.Load());require.EqualValues(t,1,p.fullCalls.Load());require.Equal(t,policy.Fingerprint(),r.client.HGet(ctx,r.lifecycleMetaKey(policy.Subject),"fingerprint").Val())
 fullRuntime,_:=owner.runtimeMetricSnapshot(ctx);partialRuntime,_:=standby.runtimeMetricSnapshot(ctx)
 t.Logf("真实Redis owner_round=%v owner_elapsed=%s owner_capacity_calls=%d owner_publish=%v; standby_elapsed=%s total_light_calls=%d standby_publish=nil; direct_capacity_bytes=%d hard=%d fingerprint_unchanged=true reclaim=0",ownerRound,ownerElapsed,ownerCapacityCalls,ownerPublish,standbyElapsed,p.capacityCalls.Load(),*available.RetainedBytes,policy.Capacity.HardBytes)
 t.Logf("owner_runtime_state=%s owner_retained=%v standby_state=%s standby_retained=%v deadline=%v",fullRuntime.State,fullRuntime.Gauges,partialRuntime.State,partialRuntime.Gauges,fullRuntime.Counters["reclaim_fail_deadline_total"])
 require.NoError(t,ownerPublish,"CAPACITY_REFRESH_OWNER_GAP: 真实Redis轻量容量可用，但owner完整检查超时没有刷新")
}
