package router

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/digitalwayhk/core/pkg/server/authstate"
	"github.com/digitalwayhk/core/pkg/server/cluster"
	"github.com/digitalwayhk/core/pkg/server/config"
	"github.com/digitalwayhk/core/pkg/server/event"
	"github.com/digitalwayhk/core/pkg/server/identity"
	"github.com/digitalwayhk/core/pkg/server/mq"
	"github.com/digitalwayhk/core/pkg/server/observability"
	"github.com/digitalwayhk/core/pkg/server/ratelimit"
	"github.com/digitalwayhk/core/pkg/server/routecache"
	"github.com/digitalwayhk/core/pkg/server/runtime"
	casdoorauth "github.com/digitalwayhk/core/pkg/server/safe/casdoor"
	"github.com/digitalwayhk/core/pkg/server/transport"
	"github.com/digitalwayhk/core/pkg/server/types"
	"github.com/digitalwayhk/core/pkg/utils"

	"github.com/gofrs/uuid"
	"github.com/yitter/idgenerator-go/idgen"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/service"
)

// processLocalRegistry is a shared in-memory cluster registry for all ServiceContexts
// within the same process. This enables intra-process MachineID conflict detection.
var processLocalRegistry = cluster.NewLocalProvider(
	config.DefaultClusterHeartbeatTimeout,
	config.DefaultClusterSuspectTimeout,
	config.DefaultClusterInstanceReuseCooldown,
)

type hmacAuthLifecycle struct {
	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup
}

func newHMACAuthLifecycle() *hmacAuthLifecycle {
	ctx, cancel := context.WithCancel(context.Background())
	return &hmacAuthLifecycle{ctx: ctx, cancel: cancel}
}

func init() {
	processLocalRegistry.Start()
}

type ServiceContext struct {
	stableIdentity           *stableIdentityRuntime
	Config                   *config.ServerConfig
	Service                  *types.Service
	snow                     idgen.ISnowWorker
	Router                   *ServiceRouter
	isStart                  atomic.Bool
	terminated               bool
	shutdownDone             chan struct{}
	shutdownOnce             sync.Once
	lifecycleMu              sync.Mutex
	lifecycleOpOnce          sync.Once
	lifecycleOp              chan struct{} // 串行化启停和 Provider 切换，但不在 Provider 调用期间持有状态锁。
	Pid                      int
	Hub                      interface{} `json:"-"`
	StateChan                chan bool   `json:"-"`
	serverOption             *types.ServerOption
	serverOptionMu           sync.RWMutex
	TransportSelector        transport.TransportSelector `json:"-"`
	TransportStats           *transport.Stats            `json:"-"`
	MQManager                *mq.MQManager               `json:"-"`
	EventStream              *event.Stream               `json:"-"`
	EventBridge              *event.MQBridge             `json:"-"`
	ServiceEventBridge       *event.ServiceEventBridge   `json:"-"`
	cacheNotificationBridge  *internalNotificationBridge
	authNotificationBridge   *internalNotificationBridge
	RouteWebSocketHub        *types.RouteWebSocketHub        `json:"-"`
	RouteCacheManager        *routecache.Manager             `json:"-"`
	PublicRateLimiter        *ratelimit.Manager              `json:"-"`
	AuthHookProvider         types.IAuthHookProvider         `json:"-"`
	AuthRequestHookProvider  types.IAuthRequestHookProvider  `json:"-"`
	ManageRoleProvider       types.IManageRoleProvider       `json:"-"`
	ManageAuthorizer         types.IManageAuthorizer         `json:"-"`
	HMACAuthProvider         types.IHMACAuthProvider         `json:"-"`
	CasdoorEventHookProvider types.ICasdoorEventHookProvider `json:"-"`
	hmacAuthSlots            chan struct{}
	hmacAuthLifecycle        *hmacAuthLifecycle
	CasdoorClients           *casdoorauth.ClientSet    `json:"-"`
	AuthRevocationManager    *authstate.Manager        `json:"-"`
	ClusterProvider          cluster.DiscoveryProvider `json:"-"`
	localFallbackProvider    cluster.DiscoveryProvider `json:"-"`
	ClusterSwitcher          cluster.ProviderSwitcher  `json:"-"`
	ServiceResolver          *ServiceResolver          `json:"-"`
	ServiceInstanceID        string
	// RuntimeAggregator 由 ServerManage 查询端持有；业务进程可为 nil。
	RuntimeAggregator   *runtime.Aggregator `json:"-"`
	runtimeAddress      string
	ownsClusterProvider bool
	membership          *cluster.MembershipManager     `json:"-"`
	CrossNodeBroker     *cluster.CrossNodeNoticeBroker `json:"-"`
	nodeID              string
	configFingerprint   string
	grpcServer          types.GRPCServerLifecycle
	grpcSupervisorOnce  sync.Once
	runtimeErrMu        sync.RWMutex
	runtimeErr          error
	runtimeFailure      chan error
	lifecycleTimeout    time.Duration
	shutdownErrMu       sync.RWMutex
	shutdownErr         error
	resources           *resourceManager
	ownedMetricsMu      sync.Mutex
	ownedMetrics        *ownedRuntimeMetrics
}

const grpcLifecycleTimeout = 5 * time.Second

// RuntimeAddress 返回当前服务实例向其他节点公布的地址。
// Cluster.AdvertiseAddress 显式配置优先，否则使用 ServiceContext 创建时捕获的本机地址。
func (own *ServiceContext) RuntimeAddress() string {
	if own == nil {
		return ""
	}
	if own.Config != nil {
		if address := strings.TrimSpace(own.Config.Cluster.AdvertiseAddress); address != "" {
			return address
		}
	}
	if address := strings.TrimSpace(own.runtimeAddress); address != "" {
		return address
	}
	return utils.GetLocalIP()
}

// UseResource 把实例级资源交给当前 ServiceContext 按注册逆序统一关闭。
func (own *ServiceContext) UseResource(name string, resource ManagedResource) error {
	if own == nil || own.resources == nil {
		return ErrResourceManagerClosed
	}
	return own.resources.Use(name, resource)
}

// RegisterRuntimeMetricProviders 注册本进程组件指标 Provider（Pending/Outbox 等）。
// 只影响本进程 Prometheus Collector；Aggregator 仍只通过 Prometheus 查询历史。
func (own *ServiceContext) RegisterRuntimeMetricProviders(providers ...observability.RuntimeMetricProvider) error {
	if own == nil || own.Service == nil {
		return fmt.Errorf("service context is not ready")
	}
	return observability.RegisterComponentProviders(own.Service.Name, providers...)
}

// SetLifecycleTimeout 配置服务注册和停止的有界等待时间。
func (own *ServiceContext) SetLifecycleTimeout(timeout time.Duration) {
	if timeout <= 0 {
		return
	}
	own.lifecycleMu.Lock()
	own.lifecycleTimeout = timeout
	own.lifecycleMu.Unlock()
}

func (own *ServiceContext) lifecycleDuration() time.Duration {
	own.lifecycleMu.Lock()
	defer own.lifecycleMu.Unlock()
	if own.lifecycleTimeout > 0 {
		return own.lifecycleTimeout
	}
	return grpcLifecycleTimeout
}

// ShutdownError 返回关闭期间首个未恢复错误；重复停止保持同一结果。
func (own *ServiceContext) ShutdownError() error {
	own.shutdownErrMu.RLock()
	defer own.shutdownErrMu.RUnlock()
	return own.shutdownErr
}

func (own *ServiceContext) recordShutdownError(err error) {
	if err == nil {
		return
	}
	own.shutdownErrMu.Lock()
	if own.shutdownErr == nil {
		own.shutdownErr = err
	}
	own.shutdownErrMu.Unlock()
}

type managedGRPCService struct {
	owner  *ServiceContext
	server types.GRPCServerLifecycle
}

func (s *managedGRPCService) Start() { s.server.Start() }
func (s *managedGRPCService) Stop()  { s.owner.SetRunState(false) }

// RuntimeError 返回服务运行期的稳定终态错误。
func (own *ServiceContext) RuntimeError() error {
	own.runtimeErrMu.RLock()
	defer own.runtimeErrMu.RUnlock()
	return own.runtimeErr
}

func (own *ServiceContext) setRuntimeError(err error) {
	if err == nil {
		return
	}
	own.runtimeErrMu.Lock()
	if own.runtimeErr == nil {
		own.runtimeErr = err
		if own.runtimeFailure == nil {
			own.runtimeFailure = make(chan error, 1)
		}
		own.runtimeFailure <- err
	}
	own.runtimeErrMu.Unlock()
}

// Failure 返回服务运行期终态错误。每个 ServiceContext 最多发布一次。
func (own *ServiceContext) Failure() <-chan error {
	own.runtimeErrMu.Lock()
	defer own.runtimeErrMu.Unlock()
	if own.runtimeFailure == nil {
		own.runtimeFailure = make(chan error, 1)
		if own.runtimeErr != nil {
			own.runtimeFailure <- own.runtimeErr
		}
	}
	return own.runtimeFailure
}

// SetGRPCServer 将服务专属 gRPC 生命周期交给 ServiceContext 管理。
func (own *ServiceContext) SetGRPCServer(server types.GRPCServerLifecycle) {
	own.lifecycleMu.Lock()
	own.grpcServer = server
	own.lifecycleMu.Unlock()
	own.superviseGRPC(server)
}

func (own *ServiceContext) waitForGRPCReady(ctx context.Context, server types.GRPCServerLifecycle) error {
	if server == nil {
		return nil
	}
	select {
	case <-server.Ready():
		select {
		case <-server.Done():
			if err := server.Err(); err != nil {
				return err
			}
			return errors.New("grpc server stopped before discovery registration")
		default:
			return nil
		}
	case <-server.Done():
		if err := server.Err(); err != nil {
			return err
		}
		return errors.New("grpc server stopped before becoming ready")
	case <-ctx.Done():
		return fmt.Errorf("wait for grpc ready: %w", ctx.Err())
	}
}

func (own *ServiceContext) superviseGRPC(server types.GRPCServerLifecycle) {
	if server == nil {
		return
	}
	own.grpcSupervisorOnce.Do(func() {
		go func() {
			<-server.Done()
			if err := server.Err(); err != nil {
				own.setRuntimeError(err)
			}
			if own.RuntimeError() != nil {
				own.SetRunState(false)
			}
		}()
	})
}

func (own *ServiceContext) beginLifecycleOperation() {
	_ = own.beginLifecycleOperationContext(context.Background())
}

func (own *ServiceContext) beginLifecycleOperationContext(ctx context.Context) error {
	own.lifecycleOpOnce.Do(func() {
		own.lifecycleOp = make(chan struct{}, 1)
		own.lifecycleOp <- struct{}{}
	})
	if ctx == nil {
		ctx = context.Background()
	}
	select {
	case <-own.lifecycleOp:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (own *ServiceContext) endLifecycleOperation() {
	own.lifecycleOp <- struct{}{}
}

func (own *ServiceContext) shutdownWaiter() (<-chan struct{}, bool) {
	own.lifecycleMu.Lock()
	defer own.lifecycleMu.Unlock()
	if !own.terminated {
		return nil, false
	}
	if own.shutdownDone == nil {
		own.shutdownDone = make(chan struct{})
	}
	return own.shutdownDone, true
}

func (own *ServiceContext) completeShutdown() {
	own.lifecycleMu.Lock()
	if !own.terminated {
		own.lifecycleMu.Unlock()
		return
	}
	if own.shutdownDone == nil {
		own.shutdownDone = make(chan struct{})
	}
	done := own.shutdownDone
	own.lifecycleMu.Unlock()
	own.shutdownOnce.Do(func() { close(done) })
}

func (own *ServiceContext) GetServerOption() *types.ServerOption {
	if own == nil {
		return nil
	}
	own.serverOptionMu.RLock()
	option := own.serverOption.Clone()
	own.serverOptionMu.RUnlock()
	if option != nil && own.Config != nil {
		option.RemoteAccessManageAPI = own.Config.RemoteAccessManageAPI
	}
	return option
}
func (own *ServiceContext) SetServerOption(so *types.ServerOption) {
	own.serverOptionMu.Lock()
	own.serverOption = so.Clone()
	own.serverOptionMu.Unlock()
}

// GetAuthRequestRuntime 返回一次请求使用的认证运行时快照。
// active 为 false 表示 ServiceContext 已进入终止阶段，新认证必须 fail closed。
func (own *ServiceContext) GetAuthRequestRuntime() (*authstate.Manager, types.IAuthRequestHookProvider, bool) {
	if own == nil {
		return nil, nil, false
	}
	own.lifecycleMu.Lock()
	defer own.lifecycleMu.Unlock()
	if own.terminated {
		return nil, nil, false
	}
	return own.AuthRevocationManager, own.AuthRequestHookProvider, true
}

// GetManageAuthorizationRuntime 返回当前 Manage RBAC Provider 与授权器快照。
// 标准 WebServer 会绑定 Core 默认实现；直接构造的 ServiceContext 可能仍为空。
// active 为 false 表示服务已终止。
func (own *ServiceContext) GetManageAuthorizationRuntime() (types.IManageRoleProvider, types.IManageAuthorizer, bool) {
	if own == nil {
		return nil, nil, false
	}
	own.lifecycleMu.Lock()
	defer own.lifecycleMu.Unlock()
	if own.terminated {
		return nil, nil, false
	}
	return own.ManageRoleProvider, own.ManageAuthorizer, true
}

// GetHMACAuthRuntime 返回 HMAC Provider 的生命周期快照。
// active 为 false 表示服务已终止；Provider 为 nil 表示服务没有实现该可选能力。
func (own *ServiceContext) GetHMACAuthRuntime() (types.IHMACAuthProvider, bool) {
	if own == nil {
		return nil, false
	}
	own.lifecycleMu.Lock()
	defer own.lifecycleMu.Unlock()
	if own.terminated {
		return nil, false
	}
	return own.HMACAuthProvider, true
}

// InvokeHMACAuth 在有界并发、超时和 panic 隔离下调用服务 HMAC Provider。
func (own *ServiceContext) InvokeHMACAuth(ctx context.Context, args types.HMACAuthArgs) (*types.HMACAuthResult, error) {
	return own.InvokePreparedHMACAuth(ctx, func(context.Context) (types.HMACAuthArgs, error) {
		return args, nil
	})
}

// InvokePreparedHMACAuth 在同一并发名额内完成未认证输入预处理和 Provider 调用。
// prepare 必须响应 ctx 取消，且不得记录凭证或原始请求体。
func (own *ServiceContext) InvokePreparedHMACAuth(
	ctx context.Context,
	prepare func(context.Context) (types.HMACAuthArgs, error),
) (*types.HMACAuthResult, error) {
	if own == nil {
		return nil, types.NewPublicError(types.ErrorKindUnauthenticated, 0, "", errors.New("HMAC authentication context unavailable"))
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if prepare == nil {
		return nil, types.NewPublicError(types.ErrorKindInternal, 0, "", errors.New("HMAC authentication preparation unavailable"))
	}
	own.lifecycleMu.Lock()
	if own.terminated || own.HMACAuthProvider == nil {
		own.lifecycleMu.Unlock()
		return nil, types.NewPublicError(types.ErrorKindUnauthenticated, 0, "", errors.New("HMAC authentication unavailable"))
	}
	provider := own.HMACAuthProvider
	if own.hmacAuthLifecycle == nil {
		own.hmacAuthLifecycle = newHMACAuthLifecycle()
	}
	lifecycle := own.hmacAuthLifecycle
	slots := own.hmacAuthSlots
	if slots == nil {
		maxInFlight := 64
		if own.Config != nil && own.Config.HMACAuth.MaxInFlight > 0 {
			maxInFlight = own.Config.HMACAuth.MaxInFlight
		}
		slots = make(chan struct{}, maxInFlight)
		own.hmacAuthSlots = slots
	}
	timeout := 3 * time.Second
	if own.Config != nil && own.Config.Timeout > 0 {
		timeout = time.Duration(own.Config.Timeout) * time.Millisecond
	}
	select {
	case slots <- struct{}{}:
	default:
		own.lifecycleMu.Unlock()
		return nil, types.NewPublicError(types.ErrorKindRateLimited, 0, "", errors.New("HMAC authentication is busy"))
	}
	lifecycle.wg.Add(1)
	own.lifecycleMu.Unlock()

	hookCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	stopLifecycleCancel := context.AfterFunc(lifecycle.ctx, cancel)
	defer stopLifecycleCancel()
	type hookResult struct {
		result *types.HMACAuthResult
		err    error
	}
	resultCh := make(chan hookResult, 1)
	go func() {
		defer func() { <-slots }()
		defer lifecycle.wg.Done()
		defer func() {
			if recover() != nil {
				resultCh <- hookResult{err: types.NewPublicError(types.ErrorKindInternal, 0, "", errors.New("HMAC authentication hook panic"))}
			}
		}()
		args, err := prepare(hookCtx)
		if err != nil {
			resultCh <- hookResult{err: err}
			return
		}
		result, err := provider.AuthenticateHMAC(hookCtx, args)
		resultCh <- hookResult{result: result, err: err}
	}()
	select {
	case result := <-resultCh:
		if hookCtx.Err() != nil {
			return nil, types.NewPublicError(types.ErrorKindInternal, 0, "", errors.New("HMAC authentication hook timeout"))
		}
		return result.result, result.err
	case <-hookCtx.Done():
		return nil, types.NewPublicError(types.ErrorKindInternal, 0, "", errors.New("HMAC authentication hook timeout"))
	}
}

// EnableEventBridge wires an in-process event.Stream to the MQManager so that
// event.Envelope values can be published and consumed via the MQ provider.
// It is called automatically during NewServiceContext when MQ.Usage contains
// "event-stream", and is also exposed for use in tests.
func (own *ServiceContext) EnableEventBridge() {
	if own.MQManager == nil {
		return
	}
	if own.EventStream == nil {
		own.EventStream = event.NewStream()
	}
	if own.ServiceEventBridge == nil {
		subscriberID := ""
		if own.Service != nil {
			subscriberID = own.Service.Name
		}
		own.ServiceEventBridge = event.NewServiceEventBridge(own.EventStream, event.ServiceEventBridgeOptions{
			SubscriberID:         subscriberID,
			InstanceSubscriberID: own.eventInstanceSubscriberID(),
		})
	}
	own.EventBridge = event.NewMQBridge(own.EventStream, own.MQManager)
	own.ServiceEventBridge.SetExternalPublisher(own.EventBridge)
}

// NewEventPublisher returns an event.IPublisher scoped to the given MQ subject.
// When an MQBridge is active (MQ mode=on/auto with event-stream usage), events
// are delivered cross-node via the MQ provider.  Otherwise they are dispatched
// in-process via the local Stream.  Returns nil if neither stream nor bridge
// has been initialised (e.g. MQ mode=off and no explicit EnableEventBridge call).
func (own *ServiceContext) NewEventPublisher(subject string) event.IPublisher {
	if own.EventStream == nil && own.EventBridge == nil {
		return nil
	}
	src := ""
	if own.Service != nil {
		src = own.Service.Name
	}
	return event.NewPublisher(own.EventStream, own.EventBridge, subject).WithSourceService(src)
}

// containsUsage reports whether usage slice contains the given value.
func containsUsage(usage []string, value string) bool {
	for _, u := range usage {
		if u == value {
			return true
		}
	}
	return false
}
func (own *ServiceContext) getStatsManager() *StatsManager {
	return NewStatsManager(own.Service.Name, own.Router.GetRouters())
}

// GetAllRouterStats 获取所有路由统计（支持过滤和排序）。
//
// Deprecated: 旧内存 RouterStats 生产路径已关闭；请使用 Runtime Aggregator
// 与 POST /api/servermanage/runtimeservice。见 docs/codex/DEPRECATION_REGISTER.md。
func (own *ServiceContext) GetAllRouterStats(
	filterTypes []types.ApiType,
	sortBy SortField,
	order SortOrder,
) *AggregatedStats {
	manager := own.getStatsManager()
	return manager.GetAllStats(filterTypes, sortBy, order)
}

// 🆕 GetPublicRouterStats 获取公共路由统计（排序）
func (own *ServiceContext) GetPublicRouterStats(
	sortBy SortField,
	order SortOrder,
) *AggregatedStats {
	return own.GetAllRouterStats(
		[]types.ApiType{types.PublicType},
		sortBy,
		order,
	)
}

// 🆕 GetPrivateRouterStats 获取私有路由统计（排序）
func (own *ServiceContext) GetPrivateRouterStats(
	sortBy SortField,
	order SortOrder,
) *AggregatedStats {
	return own.GetAllRouterStats(
		[]types.ApiType{types.PrivateType},
		sortBy,
		order,
	)
}

// 🆕 GetTopRouters 获取排名前N的路由
func (own *ServiceContext) GetTopRouters(
	n int,
	filterTypes []types.ApiType,
	sortBy SortField,
) []*types.RouterStatsSnapshot {
	manager := own.getStatsManager()
	return manager.GetTopN(n, filterTypes, sortBy)
}

// 🆕 PrintRouterStats 打印路由统计
func (own *ServiceContext) PrintRouterStats(
	filterTypes []types.ApiType,
	sortBy SortField,
) {
	manager := own.getStatsManager()
	summary := manager.GetSummary(filterTypes)
	logx.Info(summary)

	// 打印 Top 10
	manager.PrintTopStats(10, filterTypes, sortBy)
}

// 🆕 GetStatsJSON 获取JSON格式统计
func (own *ServiceContext) GetStatsJSON(
	filterTypes []types.ApiType,
	sortBy SortField,
	order SortOrder,
) string {
	manager := own.getStatsManager()
	return manager.GetStatsJSON(filterTypes, sortBy, order)
}

// 获取响应最慢的10个路由
func (own *ServiceContext) GetSlowestRoutersJSON(
	sortBy SortField,
) string {
	manager := own.getStatsManager()
	filterTypes := []types.ApiType{types.PrivateType, types.PublicType}
	topRouters := manager.GetTopN(10, filterTypes, sortBy)
	data, err := json.MarshalIndent(topRouters, "", "  ")
	if err != nil {
		logx.Error("Failed to marshal slowest routers JSON:", err)
		return ""
	}
	return string(data)
}

const DEFAULTPORT = 8080

type contextInitialization struct {
	ready      chan struct{}
	result     *ServiceContext
	panicValue interface{}
	panicked   bool
}

type serviceContextRegistry struct {
	mu                   sync.RWMutex
	contexts             map[string]*ServiceContext
	initializing         map[string]*contextInitialization
	readinessFailures    map[string]error
	nextDefaultSequence  int
	freeDefaultSequences []int
}

func newServiceContextRegistry() *serviceContextRegistry {
	return &serviceContextRegistry{
		contexts:          make(map[string]*ServiceContext),
		initializing:      make(map[string]*contextInitialization),
		readinessFailures: make(map[string]error),
	}
}

func (r *serviceContextRegistry) get(name string) *ServiceContext {
	r.mu.RLock()
	sc := r.contexts[name]
	r.mu.RUnlock()
	if sc != nil {
		if _, terminated := sc.shutdownWaiter(); terminated {
			return nil
		}
	}
	return sc
}

func (r *serviceContextRegistry) snapshot() map[string]*ServiceContext {
	r.mu.RLock()
	defer r.mu.RUnlock()

	contexts := make(map[string]*ServiceContext, len(r.contexts))
	for name, sc := range r.contexts {
		if _, terminated := sc.shutdownWaiter(); !terminated {
			contexts[name] = sc
		}
	}
	return contexts
}

func (r *serviceContextRegistry) getOrInitialize(
	name string,
	reserveDefaultSequence bool,
	requestedFingerprint string,
	initialize func(sequence int) *ServiceContext,
) *ServiceContext {
	for {
		r.mu.Lock()
		if sc := r.contexts[name]; sc != nil {
			if done, terminated := sc.shutdownWaiter(); terminated {
				r.mu.Unlock()
				<-done
				continue
			}
			r.mu.Unlock()
			assertServiceContextConfig(name, requestedFingerprint, sc)
			return sc
		}
		if entry := r.initializing[name]; entry != nil {
			r.mu.Unlock()
			<-entry.ready
			if entry.panicked {
				panic(entry.panicValue)
			}
			continue
		}
		break
	}

	sequence := -1
	if reserveDefaultSequence {
		sequence = r.reserveDefaultSequence()
	}
	entry := &contextInitialization{ready: make(chan struct{})}
	r.initializing[name] = entry
	r.mu.Unlock()

	var result *ServiceContext
	func() {
		defer func() {
			if value := recover(); value != nil {
				entry.panicValue = value
				entry.panicked = true
			}
		}()
		result = initialize(sequence)
	}()

	r.mu.Lock()
	entry.result = result
	if !entry.panicked && result != nil {
		r.contexts[name] = result
		delete(r.readinessFailures, name)
	} else if reserveDefaultSequence {
		r.freeDefaultSequences = append(r.freeDefaultSequences, sequence)
	}
	delete(r.initializing, name)
	close(entry.ready)
	r.mu.Unlock()

	if entry.panicked {
		panic(entry.panicValue)
	}
	return result
}

func assertServiceContextConfig(name, requestedFingerprint string, sc *ServiceContext) {
	if sc == nil || requestedFingerprint == "" || sc.configFingerprint == "" {
		return
	}
	if requestedFingerprint != sc.configFingerprint {
		panic(fmt.Sprintf("service context config conflict: service=%s", name))
	}
}

func (r *serviceContextRegistry) remove(name string, expected *ServiceContext) bool {
	var failure error
	if expected != nil && expected.stableIdentity != nil {
		failure = errors.Join(expected.RuntimeError(), expected.ShutdownError())
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.contexts[name] != expected {
		return false
	}
	if failure != nil {
		r.readinessFailures[name] = failure
	}
	delete(r.contexts, name)
	return true
}

// reserveDefaultSequence 必须在持有 r.mu 时调用。
func (r *serviceContextRegistry) reserveDefaultSequence() int {
	for len(r.freeDefaultSequences) > 0 {
		last := len(r.freeDefaultSequences) - 1
		sequence := r.freeDefaultSequences[last]
		r.freeDefaultSequences = r.freeDefaultSequences[:last]
		if sequence >= len(r.contexts) {
			return sequence
		}
	}
	if r.nextDefaultSequence < len(r.contexts) {
		r.nextDefaultSequence = len(r.contexts)
	}
	sequence := r.nextDefaultSequence
	r.nextDefaultSequence++
	return sequence
}

var contextRegistry = newServiceContextRegistry()

var testResultMu sync.RWMutex

// Deprecated: 为保持源码兼容暂时保留；框架内部请使用 SetTestResult 和 GetTestResult。
// 外部直接写入此 map 无法受内部锁保护，仍可能产生并发竞态。
var TestResult = make(map[string]interface{})

func SetTestResult(path string, result interface{}) {
	testResultMu.Lock()
	defer testResultMu.Unlock()
	TestResult[path] = result
}

func GetTestResult(path string) interface{} {
	testResultMu.RLock()
	defer testResultMu.RUnlock()
	return TestResult[path]
}

func NewServiceContext(service types.IService) *ServiceContext {
	name := strings.ToLower(service.ServiceName())
	con := config.ReadConfig(name)
	requestedFingerprint := ""
	if con != nil {
		normalized, fingerprint, err := normalizeServerConfig(con)
		if err != nil {
			panic(fmt.Sprintf("config validation failed: %v", err))
		}
		con = normalized
		requestedFingerprint = fingerprint
	}
	return contextRegistry.getOrInitialize(name, true, requestedFingerprint, func(sequence int) *ServiceContext {
		sc := &ServiceContext{resources: newResourceManager(), runtimeAddress: utils.GetLocalIP()}
		sc.StateChan = make(chan bool, 1)
		sc.Service = initService(service)
		if con == nil {
			port := DEFAULTPORT + sequence
			con = config.NewServiceDefaultConfig(name, port)
			con.DataCenterID = uint(sequence) + 1
			con.MachineID = 1
			if err := con.Save(); err != nil {
				panic(err)
			}
		}
		sc.Config = con
		fingerprint, err := serverConfigFingerprint(con)
		if err != nil {
			panic(err)
		}
		sc.configFingerprint = fingerprint
		initServiceContextPost(sc, service, con)
		return sc
	})
}

// NewServiceContextWithConfig creates a ServiceContext using the provided
// config directly, bypassing file-based config loading. Intended for testing
// and programmatic service bootstrap where the caller manages configuration.
func NewServiceContextWithConfig(service types.IService, con *config.ServerConfig) *ServiceContext {
	name := strings.ToLower(service.ServiceName())
	if con == nil {
		panic("config validation failed: config is nil")
	}
	normalized, fingerprint, err := normalizeServerConfig(con)
	if err != nil {
		panic(fmt.Sprintf("config validation failed: %v", err))
	}
	con = normalized
	return contextRegistry.getOrInitialize(name, false, fingerprint, func(_ int) *ServiceContext {
		sc := &ServiceContext{resources: newResourceManager(), runtimeAddress: utils.GetLocalIP()}
		sc.StateChan = make(chan bool, 1)
		sc.Service = initService(service)
		sc.Config = con
		sc.configFingerprint = fingerprint
		initServiceContextPost(sc, service, con)
		return sc
	})
}

// initServiceContextPost performs the post-config initialisation shared by
// NewServiceContext and NewServiceContextWithConfig: MachineID claiming,
// cluster/transport/MQ provider setup, Snowflake, and router wiring.
func initServiceContextPost(sc *ServiceContext, service types.IService, con *config.ServerConfig) {
	initialized := false
	defer func() {
		if initialized {
			return
		}
		failure := recover()
		cleanupInitializedServiceContext(sc)
		if failure != nil {
			panic(failure)
		}
	}()
	if provider, ok := service.(types.IAuthHookProvider); ok {
		sc.AuthHookProvider = provider
	}
	if provider, ok := service.(types.IAuthRequestHookProvider); ok {
		sc.AuthRequestHookProvider = provider
	}
	if provider, ok := service.(types.IManageRoleProvider); ok {
		sc.ManageRoleProvider = provider
	}
	if provider, ok := service.(types.IHMACAuthProvider); ok {
		sc.HMACAuthProvider = provider
		sc.hmacAuthLifecycle = newHMACAuthLifecycle()
		maxInFlight := 64
		if con != nil && con.HMACAuth.MaxInFlight > 0 {
			maxInFlight = con.HMACAuth.MaxInFlight
		}
		sc.hmacAuthSlots = make(chan struct{}, maxInFlight)
	}
	if provider, ok := service.(types.ICasdoorEventHookProvider); ok {
		sc.CasdoorEventHookProvider = provider
	}
	assertServiceRoutesRegistrationMutable(sc.Service.Name, sc.Service.Routers)
	sc.localFallbackProvider = processLocalRegistry
	sc.EventStream = event.NewStream()
	sc.ServiceEventBridge = event.NewServiceEventBridge(sc.EventStream, event.ServiceEventBridgeOptions{
		SubscriberID:         sc.Service.Name,
		InstanceSubscriberID: sc.eventInstanceSubscriberID(),
	})
	if err := sc.RegisterRuntimeMetricProviders(sc.ServiceEventBridge); err != nil {
		logx.Infow("runtime_metric_provider_register_failed",
			logx.Field("service", sc.Service.Name),
			logx.Field("component", "eventbridge"),
			logx.Field("error", err),
		)
	}
	if con.Cluster.IdentityMode == "stable" {
		var err error
		sc.stableIdentity, err = initializeStableIdentity(sc)
		if err != nil {
			panic(fmt.Sprintf("stable identity initialization failed: %v", err))
		}
	} else {
		sc.ServiceInstanceID = newServiceInstanceID(sc.Service.Name)
	}
	if err := observability.RegisterProcessLabels(sc.Service.Name, sc.ServiceInstanceID); err != nil {
		// 同进程多服务（测试 / all-in-one）时保留首次注册；非冲突错误才记日志。
		if !errors.Is(err, observability.ErrProcessLabelsConflict) {
			logx.Infow("process_labels_register_failed",
				logx.Field("service", sc.Service.Name),
				logx.Field("service_instance_id", sc.ServiceInstanceID),
				logx.Field("error", err),
			)
		}
	}

	if err := initCluster(sc); err != nil {
		if con.Cluster.Mode == "on" || sc.stableIdentity != nil {
			panic(fmt.Sprintf("cluster: required provider init failed (mode=on): %v", err))
		}
		logx.Infow("cluster_degraded",
			logx.Field("service", sc.Service.Name),
			logx.Field("error", err),
		)
	}

	// Phase 4: claim a unique MachineID before initialising Snowflake.
	// AutoMachineID uses the configured ClusterProvider; legacy fixed mode keeps
	// the process-local conflict guard used by earlier examples.
	if con.Cluster.Mode != "off" && sc.stableIdentity == nil {
		machineID, err := claimMachineID(sc, con)
		if err != nil {
			if con.Cluster.Claim.AutoMachineID {
				panic(fmt.Sprintf("cluster: AutoMachineID claim failed: %v", err))
			}
			logx.Errorf("cluster: MachineID claim failed (%v), proceeding with config value", err)
		} else {
			con.MachineID = uint(machineID)
		}
	}

	sc.RuntimeAggregator = buildRuntimeAggregator(sc)

	protocols := append([]string{con.Transport.Internal}, con.Transport.Fallback...)
	sc.ServiceResolver = NewServiceResolver(sc.ClusterProvider, GetContext, protocols...)
	if sel, selErr := transport.BuildSelector(con.Transport); selErr != nil {
		// Any error from BuildSelector means the user explicitly configured a
		// transport protocol that cannot be built (e.g. quic, mq not yet implemented).
		// This is a hard misconfiguration — prevent silent fallback to legacy HTTP.
		panic(fmt.Sprintf("transport: init failed: %v", selErr))
	} else if sel != nil {
		sc.TransportStats = &transport.Stats{}
		if defaultSelector, ok := sel.(*transport.DefaultSelector); ok {
			defaultSelector.SetStats(sc.TransportStats)
		}
		sc.TransportSelector = sel
	}
	{
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		mgr, mqErr := mq.BuildManager(ctx, &con.MQ)
		cancel()
		if mqErr != nil {
			panic(fmt.Sprintf("mq: provider init failed (mode=%s): %v", con.MQ.Mode, mqErr))
		} else {
			sc.MQManager = mgr
			if mgr != nil {
				if err := sc.RegisterRuntimeMetricProviders(mgr); err != nil {
					logx.Infow("runtime_metric_provider_register_failed",
						logx.Field("service", sc.Service.Name),
						logx.Field("component", "mq"),
						logx.Field("error", err),
					)
				}
			}
			// Wire MQ-backed event stream when usage includes "event-stream".
			if mgr != nil && containsUsage(con.MQ.Usage, "event-stream") {
				sc.EnableEventBridge()
			}
		}
	}

	casdoorEnabled := con.Auth.CasDoor.Enable || con.ManageAuth.CasDoor.Enable
	if casdoorEnabled {
		clients, err := casdoorauth.NewClientSet(con.Auth.CasDoor, con.ManageAuth.CasDoor)
		if err != nil {
			panic(fmt.Sprintf("auth lifecycle: Casdoor client init failed: %v", err))
		}
		sc.CasdoorClients = clients
		if con.AuthRevocation.Mode == config.AuthRevocationModeShared && sc.EventBridge == nil {
			panic("auth lifecycle: shared mode requires MQ event-stream")
		}
		var authEvents authstate.EventBridge = sc.ServiceEventBridge
		if con.AuthRevocation.Mode == config.AuthRevocationModeShared {
			bridge, err := sc.buildInternalNotificationBridge("identity")
			if err != nil {
				panic(fmt.Sprintf("auth lifecycle: internal notification init failed: %v", err))
			}
			sc.authNotificationBridge = bridge
			sc.registerInternalNotificationMetrics(bridge)
			authEvents = bridge
		}
		manager, err := authstate.NewManager(
			sc.Service.Name,
			con.AuthRevocation,
			authstate.WithEventBridge(authEvents),
			authstate.WithCasdoorEventHook(sc.CasdoorEventHookProvider),
		)
		if err != nil {
			panic(fmt.Sprintf("auth lifecycle: revocation manager init failed: %v", err))
		}
		sc.AuthRevocationManager = manager
	}
	sc.RouteWebSocketHub = types.NewRouteWebSocketHub(sc.Service.Name, sc.ServiceEventBridge)

	// shared 缓存必须等 MQ/EventBridge 外部适配器装配完成后再初始化，确保
	// Redis 事实缓存与跨节点失效订阅同时就绪，不允许只启动本地层。
	var cacheEvents routecache.InvalidationBridge = sc.ServiceEventBridge
	if con.RouteCache.Mode == "shared" {
		bridge, err := sc.buildInternalNotificationBridge("cache")
		if err != nil {
			if con.RouteCache.Redis.OnUnavailable != "bypass" {
				panic(fmt.Sprintf("route cache: internal notification init failed: %v", err))
			}
			cacheEvents = nil
			logx.Infow("route_cache_bypassed", logx.Field("service", sc.Service.Name), logx.Field("reason", "internal_notification_unavailable"))
		} else {
			sc.cacheNotificationBridge = bridge
			sc.registerInternalNotificationMetrics(bridge)
			cacheEvents = bridge
		}
	}
	cacheManager, cacheErr := routecache.NewManager(
		sc.Service.Name,
		con.RouteCache,
		routecache.WithInvalidationBridge(cacheEvents),
	)
	if cacheErr != nil {
		panic(fmt.Sprintf("route cache: init failed: %v", cacheErr))
	}
	sc.RouteCacheManager = cacheManager
	sc.PublicRateLimiter = ratelimit.NewManager(sc.Service.Name, 0)

	if sc.stableIdentity != nil {
		sc.snow = sc.stableIdentity.generator
	} else {
		sc.snow = utils.NewAlgorithmSnowFlake(con.MachineID, con.DataCenterID)
	}
	sc.Router = NewServiceRouter(sc, service)
	initialized = true
}

func cleanupInitializedServiceContext(sc *ServiceContext) {
	if sc == nil {
		return
	}
	if sc.cacheNotificationBridge != nil {
		_ = sc.cacheNotificationBridge.Close()
		sc.cacheNotificationBridge = nil
	}
	if sc.authNotificationBridge != nil {
		_ = sc.authNotificationBridge.Close()
		sc.authNotificationBridge = nil
	}
	if sc.AuthRevocationManager != nil {
		sc.AuthRevocationManager.BeginClose()
	}
	if sc.RouteWebSocketHub != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = sc.RouteWebSocketHub.Close(ctx)
		cancel()
	}
	if sc.RouteCacheManager != nil {
		sc.RouteCacheManager.Close()
	}
	if sc.PublicRateLimiter != nil {
		sc.PublicRateLimiter.Close()
	}
	if sc.ServiceEventBridge != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = sc.ServiceEventBridge.Close(ctx)
		cancel()
	}
	if sc.MQManager != nil {
		_ = sc.MQManager.Close()
	}
	if sc.AuthRevocationManager != nil {
		_ = sc.AuthRevocationManager.Close()
	}
	if sc.ServiceResolver != nil {
		sc.ServiceResolver.Close()
	}
	if sc.ownsClusterProvider && sc.ClusterProvider != nil {
		_ = sc.ClusterProvider.Close()
	}
	if sc.stableIdentity != nil {
		_ = sc.stableIdentity.close(!sc.stableIdentity.attempted.Load())
	}
	sc.AuthRevocationManager = nil
	sc.CasdoorClients = nil
	sc.RouteWebSocketHub = nil
	sc.RouteCacheManager = nil
	sc.PublicRateLimiter = nil
	sc.EventBridge = nil
	sc.ServiceEventBridge = nil
	sc.MQManager = nil
	sc.EventStream = nil
	sc.ServiceResolver = nil
	sc.ClusterProvider = nil
	sc.ownsClusterProvider = false
}

func assertServiceRoutesRegistrationMutable(owner string, routes []types.IRouter) {
	for _, route := range routes {
		if route == nil {
			continue
		}
		route.RouterInfo().PrepareRegistration(owner)
	}
}
func initService(iser types.IService) *types.Service {
	service := &types.Service{
		Name:     strings.ToLower(iser.ServiceName()),
		Routers:  iser.Routers(),
		Instance: iser,
	}
	return service
}
func GetContext(name string) *ServiceContext {
	if name == "" {
		return nil
	}
	return contextRegistry.get(name)
}
func GetContexts() map[string]*ServiceContext {
	return contextRegistry.snapshot()
}
func (own *ServiceContext) NewID() uint {
	if own.stableIdentity != nil {
		defer func() {
			if failure := recover(); failure != nil {
				cause, ok := failure.(error)
				if !ok || !errors.Is(cause, identity.ErrAdmissionUnavailable) {
					own.setRuntimeError(fmt.Errorf("stable generator failed: %v", failure))
					go own.SetRunState(false)
				}
				panic(failure)
			}
		}()
	}
	return uint(own.snow.NextId())
}

// OutboxRuntimeOptions 是服务显式启用的 Outbox 运行时选项。
// KeyConcurrency 零值和 1 保持历史串行行为。
type OutboxRuntimeOptions struct {
	KeyConcurrency int
	// BatchSize 是单次扫描和确认的消息上限；非正值保持底层默认100。
	BatchSize int
}

// UseOutbox 启用当前服务的可靠 Outbox 发布器。事件来源服务名固定为当前 ServiceContext。
func (own *ServiceContext) UseOutbox(store event.OutboxStore) error {
	return own.UseOutboxWithOptions(store, OutboxRuntimeOptions{})
}

// UseOutboxWithOptions 显式启用加性 Outbox 运行时能力。
func (own *ServiceContext) UseOutboxWithOptions(
	store event.OutboxStore,
	options OutboxRuntimeOptions,
) error {
	if own == nil || own.ServiceEventBridge == nil || own.Service == nil {
		return event.ErrServiceEventBridgeClosed
	}
	var admission event.OutboxAdmission
	if own.stableIdentity != nil {
		admission = own
	}
	if err := own.ServiceEventBridge.UseOutbox(event.OutboxOptions{
		Admission:      admission,
		SourceService:  own.Service.Name,
		Store:          store,
		BatchSize:      options.BatchSize,
		KeyConcurrency: options.KeyConcurrency,
		External:       own.ServiceEventBridge.HasExternalPublisher(),
	}); err != nil {
		return err
	}
	if provider := own.ServiceEventBridge.OutboxRuntimeMetricProvider(); provider != nil {
		if err := own.RegisterRuntimeMetricProviders(provider); err != nil {
			logx.Infow("runtime_metric_provider_register_failed",
				logx.Field("service", own.Service.Name),
				logx.Field("component", "outbox"),
				logx.Field("error", err),
			)
		}
	}
	return nil
}

// RequireOrderedReliableByShardKey 声明控制事件需要 ordered-reliable 能力。
// 底层 provider 不支持或未装配外部 MQ 时 fail closed。
func (own *ServiceContext) RequireOrderedReliableByShardKey() error {
	if own == nil || own.ServiceEventBridge == nil {
		return event.ErrServiceEventBridgeClosed
	}
	return own.ServiceEventBridge.RequireOrderedReliableByShardKey()
}

// RequireMessageLifecycle 声明并冻结一个 MQ Subject 的必需消费组、保留与安全回收策略。
// 底层 Provider 无法满足策略时 fail closed。
func (own *ServiceContext) RequireMessageLifecycle(ctx context.Context, policy mq.LifecyclePolicy) error {
	if own == nil || own.MQManager == nil {
		return mq.ErrNotConnected
	}
	return own.MQManager.RequireMessageLifecycle(ctx, policy)
}

// NotifyOutbox 唤醒当前服务 Outbox 发布器尽快扫描本地 Outbox 表。
func (own *ServiceContext) NotifyOutbox() {
	if own == nil || own.ServiceEventBridge == nil {
		return
	}
	own.ServiceEventBridge.NotifyOutbox()
}

// SubscribeEvent 注册统一业务事件订阅；运行时负责连接本地事件中心和外部事件桥。
func (own *ServiceContext) SubscribeEvent(subscription event.Subscription) (func(), error) {
	if own == nil || own.ServiceEventBridge == nil {
		return nil, event.ErrServiceEventBridgeClosed
	}
	if own.stableIdentity != nil && subscription.Handler != nil {
		handler := subscription.Handler
		subscription.Handler = func(ctx context.Context, env *event.Envelope) error {
			if err := own.CheckServiceAdmission(); err != nil {
				return err
			}
			return handler(ctx, env)
		}
	}
	cancel, err := own.ServiceEventBridge.SubscribeEvent(subscription)
	if err != nil {
		return nil, err
	}
	// 登记异步边订阅元数据（仅真实注册，不猜测消费者）；并导出 Prom 指标供跨进程查询。
	target := ""
	if own.Service != nil {
		target = own.Service.Name
	}
	unregister := runtime.GlobalSubscriptionIndex.Register(target, subscription.Subject, subscription.EventType, subscription.Reliable)
	return func() {
		unregister()
		if cancel != nil {
			cancel()
		}
	}, nil
}

func (own *ServiceContext) SetPid(pid int) {
	own.Pid = pid
}
func (own *ServiceContext) SetRunState(state bool) {
	own.beginLifecycleOperation()
	defer own.endLifecycleOperation()

	own.lifecycleMu.Lock()
	if own.terminated {
		own.lifecycleMu.Unlock()
		return
	}
	if own.isStart.Load() == state {
		if state {
			own.lifecycleMu.Unlock()
			return
		}
	} else {
		own.isStart.Store(state)
	}
	if !state {
		own.terminated = true
		if own.shutdownDone == nil {
			own.shutdownDone = make(chan struct{})
		}
	}
	provider := own.ClusterProvider
	switcher := own.ClusterSwitcher
	membership := own.membership
	broker := own.CrossNodeBroker
	mqManager := own.MQManager
	serviceEventBridge := own.ServiceEventBridge
	cacheNotificationBridge := own.cacheNotificationBridge
	authNotificationBridge := own.authNotificationBridge
	routeWebSocketHub := own.RouteWebSocketHub
	routeCacheManager := own.RouteCacheManager
	publicRateLimiter := own.PublicRateLimiter
	authRevocationManager := own.AuthRevocationManager
	hmacAuthLifecycle := own.hmacAuthLifecycle
	serviceResolver := own.ServiceResolver
	ownsClusterProvider := own.ownsClusterProvider
	grpcServer := own.grpcServer
	resources := own.resources
	if !state {
		own.membership = nil
		own.CrossNodeBroker = nil
		own.MQManager = nil
		own.EventBridge = nil
		own.ServiceEventBridge = nil
		own.cacheNotificationBridge = nil
		own.authNotificationBridge = nil
		own.RouteWebSocketHub = nil
		own.RouteCacheManager = nil
		own.PublicRateLimiter = nil
		own.AuthRevocationManager = nil
		own.CasdoorClients = nil
		own.AuthRequestHookProvider = nil
		own.ManageRoleProvider = nil
		own.ManageAuthorizer = nil
		own.HMACAuthProvider = nil
		own.hmacAuthLifecycle = nil
		own.CasdoorEventHookProvider = nil
		own.AuthHookProvider = nil
		own.EventStream = nil
		own.ServiceResolver = nil
		own.ownsClusterProvider = false
	}
	own.lifecycleMu.Unlock()
	if own.stableIdentity != nil && !state {
		own.stableIdentity.beginStop()
	}
	if !state {
		if cacheNotificationBridge != nil {
			if err := cacheNotificationBridge.Close(); err != nil {
				own.recordShutdownError(err)
				own.recordShutdownError(err)
			}
		}
		if authNotificationBridge != nil {
			if err := authNotificationBridge.Close(); err != nil {
				own.recordShutdownError(err)
				own.recordShutdownError(err)
			}
		}
	}
	if !state && hmacAuthLifecycle != nil {
		hmacAuthLifecycle.cancel()
		hmacDone := make(chan struct{})
		go func() {
			hmacAuthLifecycle.wg.Wait()
			close(hmacDone)
		}()
		wait := own.lifecycleDuration()
		select {
		case <-hmacDone:
		case <-time.After(wait):
			err := fmt.Errorf("HMAC authentication hooks did not stop within %s", wait)
			own.recordShutdownError(err)
			logx.Errorw("hmac_auth_shutdown_timeout",
				logx.Field("service", own.Service.Name),
				logx.Field("timeout", wait),
			)
		}
	}
	if !state && authRevocationManager != nil {
		authRevocationManager.BeginClose()
	}
	if !state && own.Router != nil {
		own.Router.unregisterRouterInfos()
	}
	if !state {
		defer func() {
			if own.stableIdentity != nil {
				own.recordShutdownError(own.stableIdentity.close(own.ShutdownError() == nil))
			}
			contextRegistry.remove(own.Service.Name, own)
			own.completeShutdown()
		}()
		if resources != nil {
			ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			if err := resources.Close(ctx); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("service_managed_resources_close_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
			cancel()
		}
	}

	if state {
		readyCtx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
		readyErr := own.waitForGRPCReady(readyCtx, grpcServer)
		cancel()
		if readyErr != nil {
			own.setRuntimeError(readyErr)
			own.isStart.Store(false)
			if own.stableIdentity != nil {
				own.stableIdentity.beginStop()
			}
			if own.Config.Cluster.Mode == "on" || own.stableIdentity != nil {
				panic(fmt.Sprintf("grpc: service %s failed before discovery registration: %v", own.Service.Name, readyErr))
			}
			return
		}
		nodeID, node, interval := own.clusterMembershipConfig()
		if provider != nil && membership == nil {
			var err error
			membership, err = own.startMembership(provider, node, interval, grpcServer)
			if err != nil {
				if own.Config.Cluster.Mode == "auto" && own.stableIdentity == nil && provider != own.localFallback() {
					failedProvider := provider
					registerErr := err
					if cleanupErr := own.cleanupFailedRegistration(failedProvider, node.ID, registerErr); cleanupErr != nil {
						err = errors.Join(registerErr, cleanupErr)
					} else {
						provider = own.localFallback()
						logx.Infow("cluster_degraded",
							logx.Field("service", own.Service.Name),
							logx.Field("provider", failedProvider.Name()),
							logx.Field("fallback_provider", provider.Name()),
							logx.Field("error", registerErr),
						)
						membership, err = own.startMembership(provider, node, interval, grpcServer)
					}
					if err == nil {
						own.lifecycleMu.Lock()
						own.ClusterProvider = provider
						own.ownsClusterProvider = false
						own.ClusterSwitcher = cluster.NewClusterSwitcher(provider, own.Service.Name)
						if own.ServiceResolver != nil {
							own.ServiceResolver.SetProvider(provider)
						}
						own.lifecycleMu.Unlock()
						if ownsClusterProvider {
							if closeErr := failedProvider.Close(); closeErr != nil {
								logx.Errorw("cluster_provider_close_failed",
									logx.Field("service", own.Service.Name),
									logx.Field("provider", failedProvider.Name()),
									logx.Field("error", closeErr),
								)
							}
						}
					}
				}
				if err != nil {
					startupErr := fmt.Errorf("cluster registration failed for service %s using provider %s: %w",
						own.Service.Name, provider.Name(), err)
					own.failStartup(startupErr, grpcServer)
					if own.Config.Cluster.Mode == "on" || own.stableIdentity != nil {
						panic(startupErr)
					}
					return
				}
			}
		}
		if provider != nil && membership != nil && broker == nil {
			broker = cluster.NewCrossNodeNoticeBroker(provider, own.Service.Name, nodeID)
			if own.TransportSelector != nil {
				broker.SetSender(own.makeCrossNodeSender())
			}
			types.SetCrossNodeForwarderForService(own.Service.Name, broker)
		}
		own.lifecycleMu.Lock()
		own.nodeID = nodeID
		own.membership = membership
		own.CrossNodeBroker = broker
		own.lifecycleMu.Unlock()
		if own.stableIdentity != nil {
			own.stableIdentity.running.Store(true)
		}
		own.superviseGRPC(grpcServer)
	} else {
		if shutdown, ok := switcher.(cluster.ProviderSwitchShutdown); ok {
			ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			own.recordShutdownError(shutdown.Shutdown(ctx, provider))
			cancel()
		}
		if grpcServer != nil {
			grpcServer.BeginShutdown()
		}
		if membership != nil {
			ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			own.recordShutdownError(membership.Stop(ctx))
			cancel()
			membership = nil
		}
		if grpcServer != nil {
			ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			if err := grpcServer.StopContext(ctx); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("grpc_server_stop_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
			cancel()
		}
		if stopper, ok := own.TransportSelector.(interface{ Stop(context.Context) error }); ok {
			ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			if err := stopper.Stop(ctx); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("transport_client_pool_stop_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
			cancel()
		}
		if serviceResolver != nil {
			serviceResolver.Close()
		}
		if routeWebSocketHub != nil {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			if err := routeWebSocketHub.Close(ctx); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("route_websocket_hub_close_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
			cancel()
		}
		if routeCacheManager != nil {
			routeCacheManager.Close()
		}
		if publicRateLimiter != nil {
			publicRateLimiter.Close()
		}
		if serviceEventBridge != nil {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			if err := serviceEventBridge.Close(ctx); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("service_event_bridge_close_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
			cancel()
		}
		if broker != nil {
			types.ClearCrossNodeForwarderForService(own.Service.Name, broker)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			broker.DrainAndStop(ctx)
			own.recordShutdownError(ctx.Err())
			cancel()
		}
		if ownsClusterProvider && provider != nil {
			if err := provider.Close(); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("cluster_provider_close_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("provider", provider.Name()),
					logx.Field("error", err),
				)
			}
		}
		if mqManager != nil {
			if err := mqManager.Close(); err != nil {
				own.recordShutdownError(err)
				logx.Errorf("mq: close failed: %v", err)
			}
		}
		if authRevocationManager != nil {
			if err := authRevocationManager.Close(); err != nil {
				own.recordShutdownError(err)
				logx.Errorw("auth_revocation_manager_close_failed",
					logx.Field("service", own.Service.Name),
					logx.Field("error", err),
				)
			}
		}
	}

	// 🔧 非阻塞发送，避免死锁
	select {
	case own.StateChan <- state:
		// 发送成功
	default:
		// 通道满了，在当前架构下这不是问题
		logx.Debugf("StateChan已满，跳过状态通知: %s", own.Service.Name)
	}
}

// SyncProviderAfterSwitch updates ClusterProvider to match the switcher's
// current provider and, if the service is already running, restarts membership
// and the CrossNode broker with the new provider.
func (own *ServiceContext) SyncProviderAfterSwitch() error {
	own.beginLifecycleOperation()
	defer own.endLifecycleOperation()
	return own.syncProviderAfterSwitch()
}

// ClusterProviderSnapshot reads provider identity and nodes within the service
// lifecycle boundary so switching and shutdown cannot replace or close it.
func (own *ServiceContext) ClusterProviderSnapshot(
	ctx context.Context,
	serviceName string,
	statuses ...cluster.NodeStatus,
) (string, []*cluster.NodeInfo, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := own.beginLifecycleOperationContext(ctx); err != nil {
		return "", nil, fmt.Errorf("cluster: wait for provider query: %w", err)
	}
	defer own.endLifecycleOperation()

	own.lifecycleMu.Lock()
	provider := own.ClusterProvider
	terminated := own.terminated
	own.lifecycleMu.Unlock()
	if terminated || provider == nil {
		return "none", []*cluster.NodeInfo{}, nil
	}
	providerName := provider.Name()
	nodes, err := provider.List(ctx, serviceName, statuses...)
	if err != nil {
		return "", nil, err
	}
	return providerName, nodes, nil
}

func (own *ServiceContext) syncProviderAfterSwitch() error {

	own.lifecycleMu.Lock()
	switcher := own.ClusterSwitcher
	oldProvider := own.ClusterProvider
	own.lifecycleMu.Unlock()
	if switcher == nil {
		return nil
	}
	newProvider := switcher.Current()
	if newProvider == oldProvider {
		return nil
	}

	own.lifecycleMu.Lock()
	running := own.isStart.Load()
	membership := own.membership
	broker := own.CrossNodeBroker
	nodeID := own.nodeID
	own.lifecycleMu.Unlock()
	if !running {
		own.lifecycleMu.Lock()
		own.ClusterProvider = newProvider
		own.ownsClusterProvider = newProvider != nil && newProvider != processLocalRegistry
		if own.ServiceResolver != nil {
			own.ServiceResolver.SetProvider(newProvider)
		}
		own.lifecycleMu.Unlock()
		return nil
	}

	if own.stableIdentity != nil {
		own.stableIdentity.observe(time.Now(), identity.ErrAdmissionUnavailable)
	}
	if membership != nil {
		stopCtx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
		stopErr := membership.Stop(stopCtx)
		cancel()
		if stopErr != nil {
			err := fmt.Errorf("switch discovery provider for service %s node %s from %s to %s: stop old membership: %w",
				own.Service.Name, nodeID, providerName(oldProvider), providerName(newProvider), stopErr)
			own.setRuntimeError(err)
			own.isStart.Store(false)
			return err
		}
	}

	nodeID, node, interval := own.clusterMembershipConfig()
	var newMembership *cluster.MembershipManager
	var newBroker *cluster.CrossNodeNoticeBroker
	if newProvider != nil {
		var err error
		newMembership, err = own.startMembership(newProvider, node, interval, own.grpcServer)
		if err != nil {
			switchErr := fmt.Errorf("switch discovery provider for service %s node %s from %s to %s: register new membership: %w",
				own.Service.Name, nodeID, providerName(oldProvider), providerName(newProvider), err)
			own.setRuntimeError(switchErr)
			own.isStart.Store(false)
			return switchErr
		}
		newBroker = cluster.NewCrossNodeNoticeBroker(newProvider, own.Service.Name, nodeID)
		if own.TransportSelector != nil {
			newBroker.SetSender(own.makeCrossNodeSender())
		}
	}
	if broker != nil {
		types.ClearCrossNodeForwarderForService(own.Service.Name, broker)
		drainCtx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
		broker.DrainAndStop(drainCtx)
		cancel()
	}
	if newBroker != nil {
		types.SetCrossNodeForwarderForService(own.Service.Name, newBroker)
	}

	own.lifecycleMu.Lock()
	own.ClusterProvider = newProvider
	own.ownsClusterProvider = newProvider != nil && newProvider != processLocalRegistry
	if own.ServiceResolver != nil {
		own.ServiceResolver.SetProvider(newProvider)
	}
	own.nodeID = nodeID
	own.membership = newMembership
	own.CrossNodeBroker = newBroker
	own.lifecycleMu.Unlock()
	return nil
}

// BeginProviderSwitch starts a provider migration inside the service lifecycle
// boundary. A target not accepted by Begin is closed before this method returns.
func (own *ServiceContext) BeginProviderSwitch(ctx context.Context, to cluster.DiscoveryProvider) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := own.beginLifecycleOperationContext(ctx); err != nil {
		return closeRejectedSwitchTarget(ctx, to, err)
	}
	defer own.endLifecycleOperation()

	own.lifecycleMu.Lock()
	terminated := own.terminated
	switcher := own.ClusterSwitcher
	own.lifecycleMu.Unlock()
	if terminated {
		return closeRejectedSwitchTarget(ctx, to, errors.New("cluster: service context is terminated"))
	}
	if switcher == nil {
		return closeRejectedSwitchTarget(ctx, to, errors.New("cluster: switcher not initialised"))
	}
	if own.stableIdentity != nil {
		if _, ok := to.(cluster.OwnedRegistry); !ok {
			return closeRejectedSwitchTarget(ctx, to, errors.New("stable target lacks atomic ownership capability"))
		}
	}
	return beginProviderSwitch(ctx, switcher, to)
}

// CompleteProviderSwitch promotes, synchronizes, and finalizes a provider
// migration as one lifecycle operation, so shutdown cannot interleave.
func (own *ServiceContext) CompleteProviderSwitch(ctx context.Context) error {
	own.beginLifecycleOperation()
	defer own.endLifecycleOperation()

	own.lifecycleMu.Lock()
	terminated := own.terminated
	running := own.isStart.Load()
	switcher := own.ClusterSwitcher
	own.lifecycleMu.Unlock()
	if terminated {
		return errors.New("cluster: service context is terminated")
	}
	if switcher == nil {
		return errors.New("cluster: switcher not initialised")
	}
	if transaction, ok := switcher.(cluster.ProviderSwitchTransaction); ok {
		if err := transaction.Promote(ctx); err != nil {
			return err
		}
		if err := own.syncProviderAfterSwitch(); err != nil {
			return err
		}
		return transaction.Finalize(ctx)
	}
	if running {
		return errors.New("cluster: running provider switch requires transactional switcher")
	}
	if err := switcher.Complete(ctx); err != nil {
		return err
	}
	return own.syncProviderAfterSwitch()
}

// RollbackProviderSwitch serializes a management rollback with service
// startup and shutdown.
func (own *ServiceContext) RollbackProviderSwitch(ctx context.Context) error {
	own.beginLifecycleOperation()
	defer own.endLifecycleOperation()

	own.lifecycleMu.Lock()
	terminated := own.terminated
	switcher := own.ClusterSwitcher
	own.lifecycleMu.Unlock()
	if terminated {
		return errors.New("cluster: service context is terminated")
	}
	if switcher == nil {
		return errors.New("cluster: switcher not initialised")
	}
	return switcher.Rollback(ctx)
}

func beginProviderSwitch(
	ctx context.Context,
	switcher cluster.ProviderSwitcher,
	to cluster.DiscoveryProvider,
) error {
	err := switcher.Begin(ctx, to)
	if err == nil {
		return nil
	}
	return closeRejectedSwitchTarget(ctx, to, err)
}

func closeRejectedSwitchTarget(
	ctx context.Context,
	to cluster.DiscoveryProvider,
	beginErr error,
) error {
	if to == nil {
		return beginErr
	}
	if ctx == nil {
		ctx = context.Background()
	}
	closeDone := make(chan error, 1)
	go func() {
		if closer, ok := to.(cluster.ContextCloser); ok {
			closeDone <- closer.CloseContext(ctx)
			return
		}
		closeDone <- to.Close()
	}()
	select {
	case closeErr := <-closeDone:
		if closeErr != nil {
			return errors.Join(beginErr, fmt.Errorf("cluster: close rejected target provider %s: %w", to.Name(), closeErr))
		}
		return beginErr
	case <-ctx.Done():
		return errors.Join(beginErr, fmt.Errorf("cluster: wait for rejected target provider %s close: %w", to.Name(), ctx.Err()))
	}
}

func providerName(provider cluster.DiscoveryProvider) string {
	if provider == nil {
		return "off"
	}
	return provider.Name()
}

func (own *ServiceContext) clusterMembershipConfig() (string, *cluster.NodeInfo, time.Duration) {
	nodeID := own.clusterNodeID(own.Config.MachineID)
	address := own.RuntimeAddress()
	node := &cluster.NodeInfo{
		ID:                nodeID,
		ServiceName:       own.Service.Name,
		ServiceInstanceID: own.ServiceInstanceID,
		DataCenterID:      int64(own.Config.DataCenterID),
		MachineID:         int64(own.Config.MachineID),
		Address:           address,
		Port:              own.Config.Port,
		GRPCPort:          own.Config.Transport.GRPC.Port,
		Weight:            1,
	}
	if own.stableIdentity != nil {
		node.StableBootID = own.stableIdentity.owner.BootID
		node.StableBootEpoch = own.stableIdentity.owner.Epoch
	}
	interval := own.Config.Cluster.HeartbeatInterval
	if interval == 0 {
		interval = 3 * time.Second
	}
	return nodeID, node, interval
}

func (own *ServiceContext) clusterNodeID(machineID uint) string {
	if own.stableIdentity != nil {
		return identity.InstanceKey(own.Service.Name, own.ServiceInstanceID)
	}
	instanceID := own.ServiceInstanceID
	if instanceID == "" {
		instanceID = "unknown"
	}
	return fmt.Sprintf("%s-%d-%d-%s", own.Service.Name, own.Config.DataCenterID, machineID, instanceID)
}

func (own *ServiceContext) startMembership(
	provider cluster.DiscoveryProvider,
	node *cluster.NodeInfo,
	interval time.Duration,
	grpcServer types.GRPCServerLifecycle,
) (*cluster.MembershipManager, error) {
	registerCtx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
	defer cancel()
	registerDone := make(chan struct{})
	if grpcServer != nil {
		go func() {
			select {
			case <-grpcServer.Done():
				cancel()
			case <-registerDone:
			}
		}()
	}
	var registerErr error
	if own.stableIdentity != nil {
		stable := own.stableIdentity
		owned, ok := provider.(cluster.OwnedRegistry)
		if !ok {
			registerErr = errors.New("stable discovery owner capability unsupported")
		} else {
			stable.attempted.Store(true)
			stable.mu.Lock()
			stable.ttl = owned.RegistrationTTL()
			if stable.ttl <= 0 {
				stable.ttl = 10 * time.Second
			}
			stable.mu.Unlock()
			started := time.Now()
			registerErr = owned.AcquireRegistration(registerCtx, node, stable.owner)
			if registerErr == nil {
				registerErr = cluster.VerifyRegistration(registerCtx, provider, node, stable.owner)
			}
			stable.observe(started, registerErr)
		}
	} else {
		registerErr = provider.Register(registerCtx, node)
	}
	if registerErr != nil {
		close(registerDone)
		return nil, fmt.Errorf("register node %s: %w", node.ID, registerErr)
	}
	close(registerDone)
	if grpcServer != nil {
		select {
		case <-grpcServer.Done():
			cleanupCtx, cleanupCancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
			var cleanupErr error
			if own.stableIdentity != nil {
				cleanupErr = provider.(cluster.OwnedRegistry).ReleaseRegistration(cleanupCtx, node, own.stableIdentity.owner)
			} else {
				cleanupErr = provider.Deregister(cleanupCtx, node.ID)
			}
			cleanupCancel()
			serveErr := grpcServer.Err()
			if serveErr == nil {
				serveErr = errors.New("grpc server stopped during discovery registration")
			}
			if cleanupErr != nil && !errors.Is(cleanupErr, cluster.ErrNodeNotFound) {
				return nil, errors.Join(serveErr, fmt.Errorf("revoke node %s: %w", node.ID, cleanupErr))
			}
			return nil, serveErr
		default:
		}
	}
	options := []cluster.MembershipOption{}
	if stable := own.stableIdentity; stable != nil {
		options = append(options, cluster.WithOwnedRegistration(node, stable.owner, stable.verify, func(start time.Time, err error) {
			stable.observe(start, err)
			if errors.Is(err, cluster.ErrRegistrationFenced) || errors.Is(err, cluster.ErrRegistrationAuthorityMissing) || errors.Is(err, identity.ErrOwnerConflict) || errors.Is(err, identity.ErrAuthorityMissing) || errors.Is(err, identity.ErrAuthorityInvalid) || errors.Is(err, identity.ErrBindingConflict) {
				own.setRuntimeError(err)
				go own.SetRunState(false)
			}
		}))
	}
	membership := cluster.NewMembershipManager(provider, node.ID, interval, options...)
	membership.Start(context.Background())
	return membership, nil
}

func (own *ServiceContext) cleanupFailedRegistration(
	provider cluster.DiscoveryProvider,
	nodeID string,
	registerErr error,
) error {
	var registrationErr *cluster.RegistrationError
	if errors.As(registerErr, &registrationErr) && registrationErr.Compensated {
		return nil
	}
	cleanupCtx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
	defer cancel()
	err := provider.Deregister(cleanupCtx, nodeID)
	if registrationErr != nil {
		if err == nil || errors.Is(err, cluster.ErrNodeNotFound) {
			return nil
		}
		return errors.Join(
			fmt.Errorf("cluster registration compensation was not confirmed: %w", registerErr),
			fmt.Errorf("cleanup failed cluster registration for node %s using provider %s: %w",
				nodeID, provider.Name(), err),
		)
	}
	if err == nil || errors.Is(err, cluster.ErrNodeNotFound) {
		return nil
	}
	return fmt.Errorf("cleanup failed cluster registration for node %s using provider %s: %w",
		nodeID, provider.Name(), err)
}

func (own *ServiceContext) localFallback() cluster.DiscoveryProvider {
	if own.localFallbackProvider != nil {
		return own.localFallbackProvider
	}
	return processLocalRegistry
}

func (own *ServiceContext) failStartup(err error, grpcServer types.GRPCServerLifecycle) {
	own.setRuntimeError(err)
	own.isStart.Store(false)
	if own.stableIdentity != nil {
		own.stableIdentity.beginStop()
	}
	if stopper, ok := own.TransportSelector.(interface{ Stop(context.Context) error }); ok {
		ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
		own.recordShutdownError(stopper.Stop(ctx))
		cancel()
	}
	if grpcServer == nil {
		return
	}
	grpcServer.BeginShutdown()
	ctx, cancel := context.WithTimeout(context.Background(), own.lifecycleDuration())
	_ = grpcServer.StopContext(ctx)
	cancel()
}

func (own *ServiceContext) IsRun() bool {
	return own.isStart.Load()
}
func (own *ServiceContext) SetHttpServer(server types.IRunServer) {
	own.Service.HttpServer = server
}
func (own *ServiceContext) GetServers() []service.Service {
	items := make([]service.Service, 0, 2+len(own.Service.GetInternalServers()))
	if own.Service.HttpServer != nil {
		items = append(items, own.Service.HttpServer)
	}
	for _, server := range own.Service.GetInternalServers() {
		if server != nil {
			items = append(items, server)
		}
	}
	if own.grpcServer != nil {
		items = append(items, &managedGRPCService{owner: own, server: own.grpcServer})
	}
	return items
}

// HandleInternalPayload 是 gRPC 服务端调用业务路由的入口。
func (own *ServiceContext) HandleInternalPayload(ctx context.Context, payload *types.PayLoad) ([]byte, error) {
	own.TransportStats.RecordInboundGRPC()
	if payload != nil && (own.Service == nil || payload.TargetService != own.Service.Name) {
		return nil, fmt.Errorf("%w: inbound target does not match listener service", ErrTargetServiceUnavailable)
	}
	// 可信业务服务身份不授予ServerManage权限，WS仅放行两个精确中继路径。
	if payload != nil && (payload.TargetPath == "/api/servermanage" || strings.HasPrefix(payload.TargetPath, "/api/servermanage/")) && !isWebSocketRelayPath(payload.TargetPath) {
		return nil, types.ErrInternalCallerForbidden
	}
	if handled, data, err := own.handleInternalMenuSnapshot(ctx, payload); handled {
		return data, err
	}
	if handled, data, err := own.handleOwnedWebSocketRelay(ctx, payload); handled {
		return data, err
	}
	// 入站路径不记录 call-edge；调用边仅在 CallService 出站记录。
	data, _, err := own.invokePayload(ctx, payload)
	return data, err
}
func (own *ServiceContext) CallTargetService(traceid string, router types.IRouter, info *types.TargetInfo, callback ...func(res types.IResponse)) (types.IResponse, error) {
	payload := GetPayLoad(traceid, own.Service.Name, "", "", "", router)
	if info != nil {
		if info.TargetAddress == "" || info.TargetPort == 0 {
			return nil, errors.New("目标地址或端口错误")
		}
		payload.TargetAddress = info.TargetAddress
		payload.TargetPort = info.TargetPort
		if info.TargetService != "" {
			payload.TargetService = info.TargetService
		}
		if info.TargetPath != "" {
			payload.TargetPath = info.TargetPath
		}
		if info.TargetToken != "" {
			payload.Token = info.TargetToken
		}
	}
	return own.CallService(payload, callback...)
}

// CallTargetNode 绕过 ServiceResolver，将请求发送到已由 ClusterProvider 确定的单个节点。
//
// 该入口用于必须逐副本校验的框架流程；普通跨服务调用仍应使用
// CallTargetService，由 ServiceResolver 选择健康副本。
func (own *ServiceContext) CallTargetNode(ctx context.Context, traceid string, api types.IRouter, info *types.TargetInfo) (types.IResponse, error) {
	if own == nil || own.Service == nil || api == nil || info == nil ||
		info.TargetService == "" || info.TargetAddress == "" || (info.TargetPort == 0 && info.TargetGRPCPort == 0) {
		return nil, errors.New("目标节点地址或端口错误")
	}
	if ctx == nil {
		ctx = context.Background()
	}
	payload := GetPayLoad(traceid, own.Service.Name, "", "", "", api)
	payload.TargetService = info.TargetService
	payload.TargetAddress = info.TargetAddress
	payload.TargetPort = info.TargetPort
	if info.TargetPath != "" {
		payload.TargetPath = info.TargetPath
	}
	if info.TargetToken != "" {
		payload.Token = info.TargetToken
	}
	endpoints := serviceTransportEndpoints(info.TargetAddress, info.TargetPort, info.TargetGRPCPort)
	ctx = types.ContextWithTrustedInternalCaller(ctx, own.Service.Name)
	start := time.Now()
	values, protocol, err := own.sendPayload(ctx, payload, endpoints)
	own.recordServiceCall(payload, protocol, err, time.Since(start))
	if err != nil {
		return nil, err
	}
	response := &Response{}
	if err := json.Unmarshal(values, response); err != nil {
		return nil, err
	}
	return response, nil
}
func (own *ServiceContext) CallServiceUseApi(api types.IRouter) (types.IResponse, error) {
	info := api.RouterInfo()
	pl := &types.PayLoad{
		TraceID:       strconv.Itoa(int(own.NewID())),
		SourceService: own.Service.Name,
		SourcePath:    "",
		TargetService: info.GetServiceName(),
		TargetPath:    info.GetPath(),
		UserId:        "",
		UserName:      "",
		ClientIP:      utils.GetLocalIP(),
		Auth:          false,
		Instance:      api,
		HttpMethod:    info.GetMethod(),
	}
	return own.CallService(pl)
}
func (own *ServiceContext) CallService(payload *types.PayLoad, callback ...func(res types.IResponse)) (types.IResponse, error) {
	return own.callService(payload, callback...)
}

// CallServiceWithKey 使用稳定业务 key 选择目标服务实例；空 key 会失败。
func (own *ServiceContext) CallServiceWithKey(payload *types.PayLoad, hashKey string, callback ...func(res types.IResponse)) (types.IResponse, error) {
	hashKey = strings.TrimSpace(hashKey)
	if hashKey == "" {
		return nil, fmt.Errorf("%w: service hash key is empty", ErrTargetServiceUnavailable)
	}
	if payload == nil {
		return nil, fmt.Errorf("%w: payload is required", ErrTargetServiceUnavailable)
	}
	keyedPayload := *payload
	keyedPayload.ServiceHashKey = hashKey
	return own.callService(&keyedPayload, callback...)
}

// OwnsServiceKey 报告当前实例是否为目标服务稳定 key 的 consistent-hash owner。
// 服务内 market/task owner gate 与跨服务 CallServiceWithKey 必须使用同一 key。
func (own *ServiceContext) OwnsServiceKey(ctx context.Context, serviceName, hashKey string) (bool, error) {
	if own == nil || own.ServiceResolver == nil || strings.TrimSpace(own.ServiceInstanceID) == "" {
		return false, fmt.Errorf("%w: service ownership resolver is unavailable", ErrTargetServiceUnavailable)
	}
	resolved, err := own.ServiceResolver.ResolveWithKey(ctx, serviceName, hashKey)
	if err != nil {
		return false, err
	}
	if resolved == nil || strings.TrimSpace(resolved.ServiceInstanceID) == "" {
		return false, fmt.Errorf("%w: keyed owner instance is unavailable", ErrTargetServiceUnavailable)
	}
	return resolved.ServiceInstanceID == own.ServiceInstanceID, nil
}

func (own *ServiceContext) callService(payload *types.PayLoad, callback ...func(res types.IResponse)) (types.IResponse, error) {
	res := &Response{}
	ctx := context.Background()
	if payload != nil && own != nil && own.Service != nil {
		payload.SourceService = own.Service.Name
		ctx = types.ContextWithTrustedInternalCaller(ctx, own.Service.Name)
	}
	if callback != nil {
		ch := make(chan types.IResponse)
		go func(own *ServiceContext, errcallback ...func(res types.IResponse)) {
			start := time.Now()
			values, protocol, err := own.invokePayload(ctx, payload)
			own.recordServiceCall(payload, protocol, err, time.Since(start))
			if err != nil {
				for _, ecb := range errcallback {
					res.err = err
					ecb(res)
				}
				ch <- res
				return
			}
			json.Unmarshal(values, res)
			ch <- res
		}(own, callback[1:]...)
		res := <-ch
		if res != nil {
			callback[0](res)
		}
	} else {
		start := time.Now()
		values, protocol, err := own.invokePayload(ctx, payload)
		own.recordServiceCall(payload, protocol, err, time.Since(start))
		if err != nil {
			logx.Errorw("service_call_failed",
				logx.Field("service", own.Service.Name),
				logx.Field("target_service", payload.TargetService),
				logx.Field("target_route", payload.TargetPath),
				logx.Field("trace_id", payload.TraceID),
				logx.Field("error", err),
			)
			return nil, err
		}
		err = json.Unmarshal(values, res)
		if err != nil {
			logx.Errorw("service_response_decode_failed",
				logx.Field("service", own.Service.Name),
				logx.Field("target_service", payload.TargetService),
				logx.Field("target_route", payload.TargetPath),
				logx.Field("trace_id", payload.TraceID),
				logx.Field("response_bytes", len(values)),
				logx.Field("error", err),
			)
			return nil, err
		}
	}
	return res, nil
}

func (own *ServiceContext) recordServiceCall(payload *types.PayLoad, protocol string, err error, d time.Duration) {
	if payload == nil {
		return
	}
	src := ""
	if own != nil && own.Service != nil {
		src = own.Service.Name
	}
	result := observability.ResultSuccess
	if err != nil {
		result = observability.ClassifyError(err)
	}
	observability.RecordCall(observability.CallLabels{
		SourceService: src,
		TargetService: payload.TargetService,
		TargetRoute:   payload.TargetPath,
		Protocol:      protocol,
		ResultClass:   result,
	}, d)
}

func (own *ServiceContext) invokePayload(ctx context.Context, payload *types.PayLoad) ([]byte, string, error) {
	if payload == nil || payload.TargetService == "" || payload.TargetPath == "" {
		return nil, "unknown", fmt.Errorf("%w: target service and path are required", ErrTargetServiceUnavailable)
	}
	if payload.TargetInstanceID != "" && own.ServiceResolver == nil {
		return nil, "unknown", ErrTargetServiceUnavailable
	}
	// 普通调用保留历史同进程快路径。Keyed 调用必须先按完整集群成员解析；
	// 否则偶然消费事件的副本会永远调用自己，与使用同一 consistent-hash key
	// 的远程调用方产生不同的 owner。
	if payload.ServiceHashKey == "" && payload.TargetInstanceID == "" {
		if local := GetContext(payload.TargetService); local != nil {
			data, err := own.dispatchLocal(ctx, payload, local)
			return data, "local", err
		}
	}
	var endpoints transport.TransportEndpoints
	if own.ServiceResolver != nil {
		var resolved *ResolvedService
		var err error
		if payload.TargetInstanceID != "" {
			resolved, err = own.ServiceResolver.ResolveInstance(ctx, payload.TargetService, payload.TargetInstanceID)
		} else if payload.ServiceHashKey != "" {
			resolved, err = own.ServiceResolver.ResolveWithKey(ctx, payload.TargetService, payload.ServiceHashKey)
		} else {
			resolved, err = own.ServiceResolver.Resolve(ctx, payload.TargetService)
		}
		if err != nil {
			return nil, "grpc", err
		}
		if payload.ServiceHashKey != "" || payload.TargetInstanceID != "" {
			if local := GetContext(payload.TargetService); local != nil &&
				resolved != nil && resolved.ServiceInstanceID != "" &&
				resolved.ServiceInstanceID == local.ServiceInstanceID {
				data, err := own.dispatchLocal(ctx, payload, local)
				return data, "local", err
			}
		}
		payload.TargetAddress = resolved.Info.TargetAddress
		payload.TargetPort = resolved.Info.TargetPort
		endpoints = resolved.Endpoints
	} else if payload.TargetAddress != "" {
		// 直接指定地址的旧调用只具备 HTTP 端点；gRPC 端点必须来自服务发现。
		endpoints = serviceTransportEndpoints(payload.TargetAddress, payload.TargetPort, 0)
	} else {
		return nil, "grpc", fmt.Errorf("%w: resolver is unavailable", ErrTargetServiceUnavailable)
	}
	return own.sendPayload(ctx, payload, endpoints)
}

func (own *ServiceContext) dispatchLocal(ctx context.Context, payload *types.PayLoad, target *ServiceContext) ([]byte, error) {
	start := time.Now()
	resultClass := observability.ResultSuccess
	defer func() {
		observability.RecordInboundRequest(
			payload.TargetService,
			payload.TargetPath,
			"local",
			resultClass,
			time.Since(start),
		)
	}()
	if target == nil || target.Router == nil {
		resultClass = observability.ResultUnavailable
		return nil, fmt.Errorf("%w: service=%s", ErrTargetServiceUnavailable, payload.TargetService)
	}
	info := target.Router.GetRouter(payload.TargetPath)
	if info == nil {
		resultClass = observability.ResultUnavailable
		return nil, fmt.Errorf("%w: route=%s", ErrTargetServiceUnavailable, payload.TargetPath)
	}
	req := ToRequest(payload)
	if req == nil {
		resultClass = observability.ResultServerError
		return nil, fmt.Errorf("%w: request context for %s", ErrTargetServiceUnavailable, payload.TargetService)
	}
	if caller, trusted := types.TrustedInternalCallerFromContext(ctx); trusted {
		req = requestWithTrustedInternalCaller(req, caller)
	}
	if err := info.AuthorizeInternalCaller(req); err != nil {
		resultClass = observability.ClassifyError(err)
		return nil, err
	}
	// 内部分发不经过 Exec；在解析结构化载荷前直接检查目标服务准入。
	if info.GetPath() != "/api/health" && info.GetPath() != "/api/ready" {
		if err := target.CheckServiceAdmission(); err != nil {
			resultClass = observability.ResultUnavailable
			return nil, types.NewPublicError(types.ErrorKindUnavailable, types.PublicCodeUnavailable, "service unavailable", err)
		}
	}
	api, err := info.ParseNew(payload.Instance)
	if err != nil {
		resultClass = observability.ClassifyError(err)
		return nil, err
	}
	response := info.ExecDo(api, req)
	if response != nil && !response.GetSuccess() {
		resultClass = observability.ClassifyError(response.GetError())
	}
	return json.Marshal(response)
}

// sendPayload 在发送前完成协议选择和健康预检。MaxRetries 只作用于预检；
// 一旦 Transport.Send 开始，无论结果是否确定，都不会重试或切换协议。
func (own *ServiceContext) sendPayload(ctx context.Context, payload *types.PayLoad, endpoints transport.TransportEndpoints) ([]byte, string, error) {
	if own.TransportSelector != nil {
		maxRetries := own.Config.Transport.MaxRetries
		if maxRetries <= 0 {
			maxRetries = 1
		}
		selection, err := transport.SelectWithRetry(
			ctx, own.TransportSelector, payload, endpoints,
			maxRetries, own.Config.Transport.RetryDelay,
		)
		if err != nil {
			return nil, "grpc", err
		}
		protocol := "grpc"
		if selection.Transport != nil {
			protocol = selection.Transport.Name()
		}
		data, err := transport.SendSelection(ctx, own.TransportSelector, selection, payload)
		return data, protocol, err
	}
	// No TransportSelector: one-shot legacy path, no retry.
	data, err := own.Service.CallService(payload)
	return data, "unknown", err
}

func buildRuntimeAggregator(sc *ServiceContext) *runtime.Aggregator {
	if sc == nil || sc.Config == nil {
		return nil
	}
	cfg := sc.Config.RuntimeObservability
	mode := runtime.NormalizeMode(cfg.Mode)
	var querier runtime.PromQuerier
	if mode == "prometheus" && strings.TrimSpace(cfg.QueryURL) != "" {
		querier = runtime.NewPromClient(cfg.QueryURL, cfg.QueryTimeout)
	}
	agg := runtime.NewAggregator(
		runtime.ProviderClusterView{Provider: sc.ClusterProvider},
		querier,
		runtime.Config{
			Mode:                 mode,
			CacheTTL:             cfg.CacheTTL,
			MaxConcurrentQueries: cfg.MaxConcurrentQueries,
		},
	)
	agg.SetSubscriptions(runtime.GlobalSubscriptionIndex)
	return agg
}

// makeCrossNodeSender creates a cross-node sender that routes through
// the configured TransportSelector when available.
func (own *ServiceContext) makeCrossNodeSender() cluster.CrossNodeSender {
	return func(ctx context.Context, target *cluster.NodeInfo, data []byte, path string) ([]byte, error) {
		payload := &types.PayLoad{
			TargetAddress: target.Address,
			TargetPort:    target.Port,
			TargetPath:    path,
			TargetService: target.ServiceName,
			Data:          data,
			Instance:      json.RawMessage(data),
			HttpMethod:    "POST",
			Auth:          true,
			SourceService: own.Service.Name,
		}
		endpoints := serviceTransportEndpoints(target.Address, target.Port, target.GRPCPort)
		attempts := own.Config.Transport.MaxRetries
		if attempts <= 0 {
			attempts = 1
		}
		selection, err := transport.SelectWithRetry(
			ctx, own.TransportSelector, payload, endpoints,
			attempts, own.Config.Transport.RetryDelay,
		)
		if err != nil {
			return nil, err
		}
		return transport.SendSelection(ctx, own.TransportSelector, selection, payload)
	}
}

func initCluster(sc *ServiceContext) error {
	provider, err := cluster.BuildProvider(&sc.Config.Cluster, processLocalRegistry)
	if err != nil {
		return err
	}
	if sc.stableIdentity != nil && sc.Config.Cluster.Mode != "off" && providerName(provider) != sc.Config.Cluster.Provider {
		if provider != nil && provider != processLocalRegistry {
			_ = provider.Close()
		}
		return errors.New("stable discovery cannot fall back to another provider")
	}
	sc.ClusterProvider = provider
	sc.ownsClusterProvider = provider != nil && provider != processLocalRegistry
	if provider != nil {
		sc.ClusterSwitcher = cluster.NewClusterSwitcher(provider, sc.Service.Name)
	} else {
		sc.ClusterSwitcher = nil
	}
	return nil
}

func newServiceInstanceID(serviceName string) string {
	id, err := uuid.NewV4()
	if err != nil {
		return fmt.Sprintf("%s-%d", serviceName, time.Now().UnixNano())
	}
	return fmt.Sprintf("%s-%s", serviceName, id.String())
}

// eventInstanceSubscriberID 按公布端点生成稳定的副本消费组，不使用重启即变的 ServiceInstanceID。
func (own *ServiceContext) eventInstanceSubscriberID() string {
	if own == nil || own.Service == nil || own.Config == nil {
		return ""
	}
	return fmt.Sprintf("%s@%s:%d:%d", own.Service.Name, own.RuntimeAddress(), own.Config.Port, own.Config.Transport.GRPC.Port)
}

// claimMachineID registers this service before Snowflake initialisation.
// AutoMachineID uses the configured provider; fixed mode preserves the
// process-local expansion behaviour used by existing single-process examples.
func claimMachineID(sc *ServiceContext, con *config.ServerConfig) (int64, error) {
	if con.Cluster.Claim.AutoMachineID {
		return claimAutoMachineID(sc, con)
	}
	return claimProcessLocalMachineID(sc, con)
}

func claimAutoMachineID(sc *ServiceContext, con *config.ServerConfig) (int64, error) {
	ctx := context.Background()
	dc := int64(con.DataCenterID)
	maxMachineID := int64(con.Cluster.Claim.MachineIDMax)
	if maxMachineID <= 0 {
		maxMachineID = 31
	}
	provider := sc.ClusterProvider
	if provider == nil {
		provider = processLocalRegistry
	}
	var lastErr error
	for attempt := int64(0); attempt <= maxMachineID; attempt++ {
		machine, err := cluster.AllocateMachineID(ctx, provider, sc.Service.Name, dc, maxMachineID)
		if err != nil {
			return int64(con.MachineID), err
		}
		node := sc.clusterNodeInfo(uint(machine))
		if err := provider.Register(ctx, node); err != nil {
			if errors.Is(err, cluster.ErrSlotConflict) {
				lastErr = err
				continue
			}
			return int64(con.MachineID), err
		}
		logx.Infow("cluster_auto_machine_id_claimed",
			logx.Field("service", sc.Service.Name),
			logx.Field("service_instance_id", sc.ServiceInstanceID),
			logx.Field("datacenter_id", dc),
			logx.Field("machine_id", machine),
			logx.Field("provider", provider.Name()),
		)
		return machine, nil
	}
	if lastErr != nil {
		return int64(con.MachineID), lastErr
	}
	return int64(con.MachineID), fmt.Errorf("cluster: all MachineID slots are full for DataCenterID=%d", dc)
}

func claimProcessLocalMachineID(sc *ServiceContext, con *config.ServerConfig) (int64, error) {
	ctx := context.Background()
	dc := int64(con.DataCenterID)
	machine := int64(con.MachineID)
	node := sc.clusterNodeInfo(uint(machine))

	err := processLocalRegistry.Register(ctx, node)
	if err == nil {
		return machine, nil
	}

	// Slot conflict — auto-allocate.
	maxMachineID := int64(1023)
	if con.Cluster.Claim.MachineIDMax > 0 {
		maxMachineID = int64(con.Cluster.Claim.MachineIDMax)
	}
	newMachine := processLocalRegistry.AllocateMachineID(sc.Service.Name, dc, maxMachineID)
	if newMachine < 0 {
		return machine, fmt.Errorf("cluster: all MachineID slots are full for DataCenterID=%d", dc)
	}
	node.ID = sc.clusterNodeID(uint(newMachine))
	node.MachineID = newMachine
	if regErr := processLocalRegistry.Register(ctx, node); regErr != nil {
		return machine, regErr
	}
	logx.Infof("cluster: auto-allocated MachineID=%d for %s (was %d)", newMachine, sc.Service.Name, machine)
	return newMachine, nil
}

func (own *ServiceContext) clusterNodeInfo(machineID uint) *cluster.NodeInfo {
	address := own.RuntimeAddress()
	return &cluster.NodeInfo{
		ID:                own.clusterNodeID(machineID),
		ServiceName:       own.Service.Name,
		ServiceInstanceID: own.ServiceInstanceID,
		DataCenterID:      int64(own.Config.DataCenterID),
		MachineID:         int64(machineID),
		Address:           address,
		Port:              own.Config.Port,
		GRPCPort:          own.Config.Transport.GRPC.Port,
		Weight:            1,
	}
}

func GetResponseData[T any](response interface{}) *T {
	res := &Response{}
	bytes, err := json.Marshal(response)
	if err != nil {
		logx.Error(err)
		return nil
	}
	err = json.Unmarshal(bytes, res)
	if err != nil {
		logx.Error(err)
		return nil
	}
	data := new(T)
	res.GetData(data)
	return data
}
func GetInstance[T any](instance interface{}) *T {
	bytes, err := json.Marshal(instance)
	if err != nil {
		logx.Error(err)
		return nil
	}
	data := new(T)
	err = json.Unmarshal(bytes, data)
	if err != nil {
		logx.Error(err)
		return nil
	}
	return data
}
